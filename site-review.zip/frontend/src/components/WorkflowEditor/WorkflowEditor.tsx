import { useCallback, useState, type ComponentType, type ReactNode } from 'react'
import {
  ReactFlow,
  MiniMap,
  Controls,
  Background,
  useNodesState,
  useEdgesState,
  addEdge,
  Connection,
  Edge,
  BackgroundVariant,
  type NodeTypes,
  type NodeMouseHandler,
  type NodeProps
} from '@xyflow/react'
import '@xyflow/react/dist/style.css'

import NodeToolbar from './NodeToolbar'
import CustomNode, {
  CustomFlowNode,
  CustomNodeConfig,
  CustomNodeData,
  CustomNodeType
} from './nodes/CustomNode'
import { WorkflowNode } from '../../types/workflow'

type FlowNode = CustomFlowNode

const nodeTypes: NodeTypes = {
  custom: CustomNode as ComponentType<NodeProps>
}

const defaultNodeData: CustomNodeData = {
  type: 'input',
  label: '未命名节点',
  config: {}
}

const initialNodes: FlowNode[] = [
  {
    id: '1',
    type: 'custom',
    position: { x: 250, y: 25 },
    data: { 
      type: 'input',
      label: '输入节点',
      config: { placeholder: '请输入文本...' }
    },
  },
  {
    id: '2',
    type: 'custom',
    position: { x: 100, y: 125 },
    data: { 
      type: 'llm',
      label: 'LLM 处理',
      config: { model: 'gpt-3.5-turbo', prompt: '处理用户输入...' }
    },
  },
  {
    id: '3',
    type: 'custom',
    position: { x: 400, y: 125 },
    data: { 
      type: 'output',
      label: '输出节点',
      config: { format: 'text' }
    },
  },
]

const initialEdges: Edge[] = [
  { id: 'e1-2', source: '1', target: '2' },
  { id: 'e2-3', source: '2', target: '3' },
]

const ensureNodeData = (node: FlowNode): CustomNodeData => ({
  ...defaultNodeData,
  ...((node.data as Partial<CustomNodeData> | undefined) ?? {})
})

export default function WorkflowEditor() {
  const [nodes, setNodes, onNodesChange] = useNodesState<FlowNode>(initialNodes)
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges)
  const [selectedNode, setSelectedNode] = useState<string | null>(null)

  const onConnect = useCallback(
    (params: Connection) => setEdges((eds) => addEdge(params, eds)),
    [setEdges],
  )

  const onNodeClick: NodeMouseHandler<FlowNode> = useCallback((_event, node) => {
    setSelectedNode(node.id)
  }, [])

  const onPaneClick = useCallback(() => {
    setSelectedNode(null)
  }, [])

  const addNode = useCallback((type: WorkflowNode['type']) => {
    const nodeConfig: Record<CustomNodeType, CustomNodeConfig> = {
      input: { placeholder: '请输入文本...' },
      llm: { model: 'gpt-3.5-turbo', prompt: '处理输入...' },
      tool: { toolName: '', parameters: {} },
      condition: { condition: '', trueOutput: '', falseOutput: '' },
      output: { format: 'text' }
    }

    const newNode: FlowNode = {
      id: `node_${Date.now()}`,
      type: 'custom',
      position: { 
        x: Math.random() * 400,
        y: Math.random() * 400
      },
      data: {
        type,
        label: `${type === 'llm' ? 'LLM' : type} 节点`,
        config: nodeConfig[type]
      }
    }

    setNodes((nds) => [...nds, newNode])
  }, [setNodes])

  const updateNodeConfig = useCallback((nodeId: string, config: CustomNodeConfig) => {
    setNodes((nds) =>
      nds.map(node => {
        if (node.id !== nodeId) return node
        const currentData = ensureNodeData(node)
        return {
          ...node,
          data: {
            ...currentData,
            config
          }
        }
      })
    )
  }, [setNodes])

  const deleteNode = useCallback((nodeId: string) => {
    setNodes((nds) => nds.filter(node => node.id !== nodeId))
    setEdges((eds) => eds.filter(edge => edge.source !== nodeId && edge.target !== nodeId))
    setSelectedNode(null)
  }, [setNodes, setEdges])

  // 导出工作流配置
  const exportWorkflow = useCallback(() => {
    const workflowData = {
      exportedAt: new Date().toISOString(),
      version: '1.0',
      workflow: {
        nodes: nodes.map(node => ({
          id: node.id,
          type: ensureNodeData(node).type,
          label: ensureNodeData(node).label,
          position: node.position,
          config: ensureNodeData(node).config
        })),
        edges: edges.map(edge => ({
          id: edge.id,
          source: edge.source,
          target: edge.target,
          sourceHandle: edge.sourceHandle,
          targetHandle: edge.targetHandle
        }))
      }
    }

    // 创建下载链接
    const blob = new Blob([JSON.stringify(workflowData, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = `workflow-${new Date().toISOString().slice(0, 10)}.json`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    URL.revokeObjectURL(url)
  }, [nodes, edges])

  return (
    <div className="w-full h-full flex">
      <NodeToolbar
        onAddNode={addNode}
        onExport={exportWorkflow}
      />
      
      <div className="flex-1 relative">
        <ReactFlow<FlowNode>
          nodes={nodes}
          edges={edges}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          onConnect={onConnect}
          onNodeClick={onNodeClick}
          onPaneClick={onPaneClick}
          nodeTypes={nodeTypes}
          fitView
          className="bg-gray-50"
        >
          <Controls />
          <MiniMap />
          <Background variant={BackgroundVariant.Dots} gap={12} size={1} />
        </ReactFlow>

        {(() => {
          if (!selectedNode) return null
          const activeNode = nodes.find(n => n.id === selectedNode)
          if (!activeNode) return null
          return (
            <div className="absolute top-4 right-4 w-80 bg-white rounded-lg shadow-lg border p-4">
              <h3 className="font-semibold mb-4">节点配置</h3>
              <NodeConfigPanel
                node={activeNode}
                onUpdateConfig={(config) => updateNodeConfig(selectedNode, config)}
                onDelete={() => deleteNode(selectedNode)}
              />
            </div>
          )
        })()}
      </div>
    </div>
  )
}

interface NodeConfigPanelProps {
  node: FlowNode
  onUpdateConfig: (config: CustomNodeConfig) => void
  onDelete: () => void
}

function NodeConfigPanel({ node, onUpdateConfig, onDelete }: NodeConfigPanelProps) {
  const nodeData = ensureNodeData(node)
  const [config, setConfig] = useState<CustomNodeConfig>(nodeData.config ?? {})

  const handleConfigChange = <K extends keyof CustomNodeConfig>(key: K, value: CustomNodeConfig[K]) => {
    const newConfig: CustomNodeConfig = { ...config, [key]: value }
    setConfig(newConfig)
    onUpdateConfig(newConfig)
  }

  const renderConfigFields = (): ReactNode => {
    switch (nodeData.type) {
      case 'input':
        return (
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              占位符文本
            </label>
            <input
              type="text"
              value={config.placeholder ?? ''}
              onChange={(e) => handleConfigChange('placeholder', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary-500 focus:border-primary-500"
            />
          </div>
        )
      
      case 'llm':
        return (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                模型
              </label>
              <select
                value={config.model ?? 'gpt-3.5-turbo'}
                onChange={(e) => handleConfigChange('model', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary-500 focus:border-primary-500"
              >
                <option value="gpt-3.5-turbo">GPT-3.5 Turbo</option>
                <option value="gpt-4">GPT-4</option>
                <option value="claude-3-sonnet">Claude 3 Sonnet</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                提示词
              </label>
              <textarea
                value={config.prompt ?? ''}
                onChange={(e) => handleConfigChange('prompt', e.target.value)}
                rows={4}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary-500 focus:border-primary-500"
              />
            </div>
          </div>
        )
      
      case 'output':
        return (
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              输出格式
            </label>
            <select
              value={config.format ?? 'text'}
              onChange={(e) => handleConfigChange('format', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary-500 focus:border-primary-500"
            >
              <option value="text">文本</option>
              <option value="json">JSON</option>
              <option value="markdown">Markdown</option>
            </select>
          </div>
        )
      
      default:
        return <div>暂无配置项</div>
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h4 className="font-medium">{nodeData.label}</h4>
        <button
          onClick={onDelete}
          className="text-red-600 hover:text-red-800 text-sm"
        >
          删除
        </button>
      </div>
      
      {renderConfigFields()}
    </div>
  )
}
