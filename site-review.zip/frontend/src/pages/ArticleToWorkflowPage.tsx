import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import axios from 'axios'
import WorkflowResultModal from '../components/WorkflowResultModal'

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000/api'

export default function ArticleToWorkflowPage() {
  const navigate = useNavigate()
  const [articleUrl, setArticleUrl] = useState('')
  const [isGenerating, setIsGenerating] = useState(false)
  const [error, setError] = useState('')
  const [mockMode, setMockMode] = useState(false) // 模拟模式开关
  const [progress, setProgress] = useState({
    step: 0,
    message: ''
  })

  // 弹窗状态
  const [showModal, setShowModal] = useState(false)
  const [generatedWorkflow, setGeneratedWorkflow] = useState<any>(null)
  const [analysisResult, setAnalysisResult] = useState<any>(null)

  const validateUrl = (url: string): boolean => {
    try {
      new URL(url)
      return true
    } catch {
      return false
    }
  }

  const handleGenerate = async () => {
    // 验证 URL
    if (!articleUrl.trim()) {
      setError('请输入文章 URL')
      return
    }

    if (!validateUrl(articleUrl)) {
      setError('请输入有效的 URL 格式')
      return
    }

    setError('')
    setIsGenerating(true)
    setProgress({ step: 1, message: '正在抓取文章内容...' })

    try {
      const token = localStorage.getItem('token')
      if (!token) {
        navigate('/login', { state: { from: '/article-to-workflow' } })
        return
      }

      // 模拟进度更新
      setTimeout(() => {
        setProgress({ step: 2, message: '正在分析文章结构...' })
      }, 1000)

      setTimeout(() => {
        setProgress({ step: 3, message: '正在提取工作流步骤...' })
      }, 2000)

      setTimeout(() => {
        setProgress({ step: 4, message: '正在生成工作流节点...' })
      }, 3000)

      // 根据模拟模式选择不同的API端点
      const endpoint = mockMode
        ? `${API_BASE_URL}/workflows/generate/from-article-mock`
        : `${API_BASE_URL}/workflows/generate/from-article`

      const response = await axios.post(
        endpoint,
        {
          url: articleUrl,
          autoSave: true
        },
        {
          headers: {
            Authorization: `Bearer ${token}`
          }
        }
      )

      setProgress({ step: 5, message: '工作流创建成功！' })

      // 生成成功，显示弹窗
      if (response.data.workflow?.id) {
        setGeneratedWorkflow(response.data.workflow)
        setAnalysisResult(response.data.analysis)
        setTimeout(() => {
          setShowModal(true)
        }, 500)
      }
    } catch (err: any) {
      console.error('生成工作流失败:', err)
      setError(err.response?.data?.error || '生成工作流失败，请稍后重试')
      setProgress({ step: 0, message: '' })
    } finally {
      setTimeout(() => {
        setIsGenerating(false)
      }, 1000)
    }
  }

  return (
    <div
      style={{
        minHeight: 'calc(100vh - 64px)',
        background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
        padding: '3rem 1rem',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }}
    >
      <div
        style={{
          maxWidth: '800px',
          width: '100%',
          margin: '0 auto'
        }}
      >
        {/* 返回按钮 */}
        <button
          onClick={() => navigate(-1)}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '0.5rem',
            padding: '0.5rem 1rem',
            backgroundColor: 'rgba(255, 255, 255, 0.2)',
            border: '1px solid rgba(255, 255, 255, 0.3)',
            borderRadius: '8px',
            fontSize: '14px',
            color: 'white',
            cursor: 'pointer',
            marginBottom: '2rem',
            fontWeight: '500',
            transition: 'all 0.2s',
            backdropFilter: 'blur(10px)'
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.3)'
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.2)'
          }}
        >
          ← 返回
        </button>

        {/* 主卡片 */}
        <div
          style={{
            backgroundColor: 'white',
            borderRadius: '24px',
            padding: '3rem',
            boxShadow: '0 20px 60px rgba(0, 0, 0, 0.3)',
            border: '1px solid rgba(255, 255, 255, 0.3)'
          }}
        >
          {/* 标题区域 */}
          <div style={{ textAlign: 'center', marginBottom: '2.5rem' }}>
            <div
              style={{
                fontSize: '48px',
                marginBottom: '1rem'
              }}
            >
              🧠
            </div>
            <h1
              style={{
                fontSize: '2rem',
                fontWeight: '700',
                color: '#111827',
                marginBottom: '0.75rem',
                background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text'
              }}
            >
              文章转工作流
            </h1>
            <p
              style={{
                fontSize: '16px',
                color: '#6b7280',
                lineHeight: '1.6',
                maxWidth: '500px',
                margin: '0 auto'
              }}
            >
              输入文章 URL，一键生成智能知识提取工作流
              <br />
              自动提取实体、关系，构建知识图谱
            </p>
          </div>

          {/* 输入区域 */}
          <div style={{ marginBottom: '2rem' }}>
            <label
              style={{
                display: 'block',
                fontSize: '14px',
                fontWeight: '600',
                color: '#374151',
                marginBottom: '0.75rem'
              }}
            >
              文章 URL
            </label>
            <div style={{ position: 'relative' }}>
              <input
                type="url"
                value={articleUrl}
                onChange={(e) => {
                  setArticleUrl(e.target.value)
                  setError('')
                }}
                onKeyPress={(e) => {
                  if (e.key === 'Enter' && !isGenerating) {
                    handleGenerate()
                  }
                }}
                placeholder="https://example.com/article"
                disabled={isGenerating}
                style={{
                  width: '100%',
                  padding: '1rem 1.25rem',
                  border: error ? '2px solid #ef4444' : '2px solid #e5e7eb',
                  borderRadius: '12px',
                  fontSize: '15px',
                  outline: 'none',
                  transition: 'all 0.2s',
                  backgroundColor: isGenerating ? '#f9fafb' : 'white'
                }}
                onFocus={(e) => {
                  if (!error) {
                    e.currentTarget.style.borderColor = '#8b5cf6'
                    e.currentTarget.style.boxShadow = '0 0 0 4px rgba(139, 92, 246, 0.1)'
                  }
                }}
                onBlur={(e) => {
                  if (!error) {
                    e.currentTarget.style.borderColor = '#e5e7eb'
                    e.currentTarget.style.boxShadow = 'none'
                  }
                }}
              />
            </div>
            {error && (
              <div
                style={{
                  marginTop: '0.75rem',
                  fontSize: '14px',
                  color: '#ef4444',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.5rem'
                }}
              >
                <span>⚠️</span>
                {error}
              </div>
            )}
          </div>

          {/* 模拟模式开关 */}
          <div
            style={{
              marginBottom: '1.5rem',
              padding: '1rem',
              backgroundColor: mockMode ? '#fef3c7' : '#f3f4f6',
              borderRadius: '12px',
              border: mockMode ? '2px solid #fbbf24' : '2px solid #e5e7eb',
              transition: 'all 0.3s'
            }}
          >
            <label
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.75rem',
                cursor: 'pointer',
                userSelect: 'none'
              }}
            >
              <input
                type="checkbox"
                checked={mockMode}
                onChange={(e) => setMockMode(e.target.checked)}
                disabled={isGenerating}
                style={{
                  width: '20px',
                  height: '20px',
                  cursor: isGenerating ? 'not-allowed' : 'pointer',
                  accentColor: '#f59e0b'
                }}
              />
              <div style={{ flex: 1 }}>
                <div
                  style={{
                    fontSize: '14px',
                    fontWeight: '600',
                    color: mockMode ? '#92400e' : '#374151',
                    marginBottom: '0.25rem',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.5rem'
                  }}
                >
                  <span>{mockMode ? '🧪' : '⚡'}</span>
                  <span>{mockMode ? '测试模式已启用' : '智能AI模式'}</span>
                </div>
                <div
                  style={{
                    fontSize: '12px',
                    color: mockMode ? '#78350f' : '#6b7280',
                    lineHeight: '1.5'
                  }}
                >
                  {mockMode
                    ? '使用预设模板快速测试，无需OpenAI API密钥'
                    : '使用真实AI分析文章内容（需要OpenAI API密钥）'}
                </div>
              </div>
            </label>
          </div>

          {/* 进度显示 */}
          {isGenerating && progress.step > 0 && (
            <div
              style={{
                marginBottom: '1rem',
                padding: '1rem',
                backgroundColor: '#eff6ff',
                borderRadius: '12px',
                border: '1px solid #dbeafe'
              }}
            >
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.75rem',
                  marginBottom: '0.75rem'
                }}
              >
                <div
                  style={{
                    width: '24px',
                    height: '24px',
                    border: '3px solid rgba(96, 165, 250, 0.3)',
                    borderTop: '3px solid #3b82f6',
                    borderRadius: '50%',
                    animation: 'spin 1s linear infinite'
                  }}
                />
                <span
                  style={{
                    fontSize: '14px',
                    color: '#1e40af',
                    fontWeight: '500'
                  }}
                >
                  {progress.message}
                </span>
              </div>
              <div
                style={{
                  width: '100%',
                  height: '6px',
                  backgroundColor: '#dbeafe',
                  borderRadius: '3px',
                  overflow: 'hidden'
                }}
              >
                <div
                  style={{
                    width: `${(progress.step / 5) * 100}%`,
                    height: '100%',
                    backgroundColor: '#3b82f6',
                    transition: 'width 0.5s ease',
                    borderRadius: '3px'
                  }}
                />
              </div>
            </div>
          )}

          {/* 生成按钮 */}
          <button
            onClick={handleGenerate}
            disabled={isGenerating || !articleUrl.trim()}
            style={{
              width: '100%',
              padding: '1.125rem',
              background: isGenerating || !articleUrl.trim()
                ? '#e5e7eb'
                : 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
              color: isGenerating || !articleUrl.trim() ? '#9ca3af' : 'white',
              border: 'none',
              borderRadius: '12px',
              fontSize: '16px',
              fontWeight: '600',
              cursor: isGenerating || !articleUrl.trim() ? 'not-allowed' : 'pointer',
              transition: 'all 0.3s',
              boxShadow: !isGenerating && articleUrl.trim()
                ? '0 8px 20px rgba(102, 126, 234, 0.4)'
                : 'none',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '0.75rem'
            }}
            onMouseEnter={(e) => {
              if (!isGenerating && articleUrl.trim()) {
                e.currentTarget.style.transform = 'translateY(-2px)'
                e.currentTarget.style.boxShadow = '0 12px 28px rgba(102, 126, 234, 0.5)'
              }
            }}
            onMouseLeave={(e) => {
              if (!isGenerating && articleUrl.trim()) {
                e.currentTarget.style.transform = 'translateY(0)'
                e.currentTarget.style.boxShadow = '0 8px 20px rgba(102, 126, 234, 0.4)'
              }
            }}
          >
            {isGenerating ? (
              <>
                <div
                  style={{
                    width: '20px',
                    height: '20px',
                    border: '3px solid rgba(156, 163, 175, 0.3)',
                    borderTop: '3px solid #9ca3af',
                    borderRadius: '50%',
                    animation: 'spin 1s linear infinite'
                  }}
                />
                <span>分析中...</span>
              </>
            ) : (
              <>
                <span>🤖</span>
                <span>智能生成工作流</span>
              </>
            )}
          </button>

          {/* 功能说明 */}
          <div
            style={{
              marginTop: '2.5rem',
              padding: '1.5rem',
              backgroundColor: '#f9fafb',
              borderRadius: '16px',
              border: '1px solid #e5e7eb'
            }}
          >
            <h3
              style={{
                fontSize: '14px',
                fontWeight: '600',
                color: '#111827',
                marginBottom: '1rem',
                display: 'flex',
                alignItems: 'center',
                gap: '0.5rem'
              }}
            >
              <span>🤖</span>
              <span>AI 将自动分析文章并提取工作流：</span>
            </h3>
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(2, 1fr)',
                gap: '0.75rem'
              }}
            >
              {[
                { icon: '🌐', label: '抓取文章内容' },
                { icon: '📖', label: '分析文章结构' },
                { icon: '🔍', label: '识别工作流程' },
                { icon: '🎯', label: '提取关键步骤' },
                { icon: '⚙️', label: '生成工作节点' },
                { icon: '🔗', label: '建立节点连接' }
              ].map((step, index) => (
                <div
                  key={index}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.5rem',
                    fontSize: '13px',
                    color: '#4b5563',
                    padding: '0.5rem',
                    backgroundColor: 'white',
                    borderRadius: '8px',
                    border: '1px solid #e5e7eb'
                  }}
                >
                  <span style={{ fontSize: '18px' }}>{step.icon}</span>
                  <span style={{ fontWeight: '500' }}>{step.label}</span>
                </div>
              ))}
            </div>
          </div>

          {/* 提示信息 */}
          <div
            style={{
              marginTop: '1.5rem',
              padding: '1rem',
              backgroundColor: '#eff6ff',
              borderRadius: '12px',
              border: '1px solid #dbeafe'
            }}
          >
            <div
              style={{
                fontSize: '13px',
                color: '#1e40af',
                lineHeight: '1.6'
              }}
            >
              <strong>💡 智能工作流生成：</strong>
              <ul style={{ margin: '0.5rem 0 0 0', paddingLeft: '1.25rem' }}>
                <li>AI 会分析文章中描述的流程、步骤和方法</li>
                <li>自动识别每个步骤的类型（AI处理、工具调用、条件判断等）</li>
                <li>生成可视化的工作流节点和连接</li>
                <li>生成后可在编辑器中自定义调整</li>
              </ul>
            </div>
          </div>

          {/* 示例 */}
          <div
            style={{
              marginTop: '1.5rem',
              padding: '1rem',
              backgroundColor: '#fef3c7',
              borderRadius: '12px',
              border: '1px solid #fde68a'
            }}
          >
            <div
              style={{
                fontSize: '13px',
                color: '#92400e',
                lineHeight: '1.6'
              }}
            >
              <strong>📝 示例文章类型：</strong>
              <ul style={{ margin: '0.5rem 0 0 0', paddingLeft: '1.25rem' }}>
                <li>"如何写一篇SEO友好的博客文章" → 博客创作工作流</li>
                <li>"数据分析的5个步骤" → 数据分析工作流</li>
                <li>"产品设计流程详解" → 产品设计工作流</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* 添加旋转动画 */}
      <style>
        {`
          @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
          }
        `}
      </style>

      {/* 工作流结果弹窗 */}
      {showModal && generatedWorkflow && (
        <WorkflowResultModal
          workflow={generatedWorkflow}
          analysis={analysisResult}
          testMode={mockMode}
          onClose={() => {
            setShowModal(false)
            setGeneratedWorkflow(null)
            setAnalysisResult(null)
          }}
        />
      )}
    </div>
  )
}
