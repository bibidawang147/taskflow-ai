import { useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'

interface Step {
  id: string
  title: string
  description: string
}

export default function CreateWorkflowPage() {
  const location = useLocation()
  const navigate = useNavigate()

  // 获取从搜索页面传来的数据
  const userRequirement = location.state?.userRequirement || ''
  const suggestedSteps = location.state?.suggestedSteps || []

  const [workflowName, setWorkflowName] = useState('')
  const [workflowDescription, setWorkflowDescription] = useState('')
  const [steps, setSteps] = useState<Step[]>(
    suggestedSteps.map((stepTitle: string, index: number) => ({
      id: `step-${index + 1}`,
      title: stepTitle,
      description: ''
    }))
  )

  const addStep = () => {
    const newStep: Step = {
      id: `step-${steps.length + 1}`,
      title: `步骤 ${steps.length + 1}`,
      description: ''
    }
    setSteps([...steps, newStep])
  }

  const updateStep = (id: string, field: 'title' | 'description', value: string) => {
    setSteps(steps.map(step =>
      step.id === id ? { ...step, [field]: value } : step
    ))
  }

  const removeStep = (id: string) => {
    setSteps(steps.filter(step => step.id !== id))
  }

  const moveStep = (index: number, direction: 'up' | 'down') => {
    const newSteps = [...steps]
    if (direction === 'up' && index > 0) {
      [newSteps[index], newSteps[index - 1]] = [newSteps[index - 1], newSteps[index]]
    } else if (direction === 'down' && index < steps.length - 1) {
      [newSteps[index], newSteps[index + 1]] = [newSteps[index + 1], newSteps[index]]
    }
    setSteps(newSteps)
  }

  const handleSave = () => {
    // 保存工作流逻辑
    console.log('保存工作流', { workflowName, workflowDescription, steps })
    alert('工作流已保存！')
  }

  const handlePublish = () => {
    // 发布工作流逻辑
    console.log('发布工作流', { workflowName, workflowDescription, steps })
    alert('工作流已发布！')
  }

  return (
    <div style={{
      minHeight: 'calc(100vh - 64px)',
      backgroundColor: '#f9fafb',
      padding: '2rem'
    }}>
      <div style={{
        maxWidth: '1200px',
        margin: '0 auto'
      }}>
        {/* 返回按钮 */}
        <button
          onClick={() => navigate(-1)}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '0.5rem',
            padding: '0.5rem 1rem',
            backgroundColor: 'white',
            border: '1px solid #e5e7eb',
            borderRadius: '8px',
            fontSize: '14px',
            color: '#6b7280',
            cursor: 'pointer',
            marginBottom: '1.5rem',
            fontWeight: '500',
            transition: 'all 0.2s'
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.backgroundColor = '#f9fafb'
            e.currentTarget.style.borderColor = '#d1d5db'
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.backgroundColor = 'white'
            e.currentTarget.style.borderColor = '#e5e7eb'
          }}
        >
          ← 返回
        </button>

        <h1 style={{
          fontSize: '1.875rem',
          fontWeight: '700',
          color: '#111827',
          marginBottom: '0.5rem'
        }}>
          创建专属工作流
        </h1>
        <p style={{
          fontSize: '15px',
          color: '#6b7280',
          marginBottom: '2rem'
        }}>
          根据您的需求定制化工作流，帮您高效完成任务
        </p>

        <div style={{
          display: 'grid',
          gridTemplateColumns: '2fr 1fr',
          gap: '1.5rem'
        }}>
          {/* 左侧：工作流编辑区 */}
          <div style={{
            display: 'flex',
            flexDirection: 'column',
            gap: '1.5rem'
          }}>
            {/* 基本信息 */}
            <div style={{
              backgroundColor: 'white',
              borderRadius: '16px',
              border: '1px solid #e5e7eb',
              padding: '1.5rem',
              boxShadow: '0 1px 3px rgba(0, 0, 0, 0.05)'
            }}>
              <h3 style={{
                fontSize: '1rem',
                fontWeight: '600',
                color: '#111827',
                marginBottom: '1rem'
              }}>
                基本信息
              </h3>

              <div style={{ marginBottom: '1rem' }}>
                <label style={{
                  display: 'block',
                  fontSize: '14px',
                  fontWeight: '500',
                  color: '#374151',
                  marginBottom: '0.5rem'
                }}>
                  工作流名称 *
                </label>
                <input
                  type="text"
                  value={workflowName}
                  onChange={(e) => setWorkflowName(e.target.value)}
                  placeholder="例如：AI文章生成助手"
                  style={{
                    width: '100%',
                    padding: '0.75rem',
                    border: '1px solid #e5e7eb',
                    borderRadius: '8px',
                    fontSize: '14px',
                    outline: 'none',
                    transition: 'all 0.2s'
                  }}
                  onFocus={(e) => {
                    e.currentTarget.style.borderColor = '#8b5cf6'
                    e.currentTarget.style.boxShadow = '0 0 0 3px rgba(139, 92, 246, 0.1)'
                  }}
                  onBlur={(e) => {
                    e.currentTarget.style.borderColor = '#e5e7eb'
                    e.currentTarget.style.boxShadow = 'none'
                  }}
                />
              </div>

              <div>
                <label style={{
                  display: 'block',
                  fontSize: '14px',
                  fontWeight: '500',
                  color: '#374151',
                  marginBottom: '0.5rem'
                }}>
                  工作流描述
                </label>
                <textarea
                  value={workflowDescription}
                  onChange={(e) => setWorkflowDescription(e.target.value)}
                  placeholder="简要描述这个工作流的功能和用途..."
                  rows={3}
                  style={{
                    width: '100%',
                    padding: '0.75rem',
                    border: '1px solid #e5e7eb',
                    borderRadius: '8px',
                    fontSize: '14px',
                    outline: 'none',
                    resize: 'vertical',
                    fontFamily: 'inherit',
                    transition: 'all 0.2s'
                  }}
                  onFocus={(e) => {
                    e.currentTarget.style.borderColor = '#8b5cf6'
                    e.currentTarget.style.boxShadow = '0 0 0 3px rgba(139, 92, 246, 0.1)'
                  }}
                  onBlur={(e) => {
                    e.currentTarget.style.borderColor = '#e5e7eb'
                    e.currentTarget.style.boxShadow = 'none'
                  }}
                />
              </div>
            </div>

            {/* 工作流步骤 */}
            <div style={{
              backgroundColor: 'white',
              borderRadius: '16px',
              border: '1px solid #e5e7eb',
              padding: '1.5rem',
              boxShadow: '0 1px 3px rgba(0, 0, 0, 0.05)'
            }}>
              <div style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                marginBottom: '1rem'
              }}>
                <h3 style={{
                  fontSize: '1rem',
                  fontWeight: '600',
                  color: '#111827',
                  margin: 0
                }}>
                  工作流步骤
                </h3>
                <button
                  onClick={addStep}
                  style={{
                    padding: '0.5rem 1rem',
                    backgroundColor: '#8b5cf6',
                    color: 'white',
                    border: 'none',
                    borderRadius: '6px',
                    fontSize: '13px',
                    fontWeight: '500',
                    cursor: 'pointer',
                    transition: 'all 0.2s'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.backgroundColor = '#7c3aed'
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.backgroundColor = '#8b5cf6'
                  }}
                >
                  + 添加步骤
                </button>
              </div>

              <div style={{
                display: 'flex',
                flexDirection: 'column',
                gap: '1rem'
              }}>
                {steps.map((step, index) => (
                  <div
                    key={step.id}
                    style={{
                      padding: '1rem',
                      backgroundColor: '#f9fafb',
                      borderRadius: '12px',
                      border: '1px solid #e5e7eb'
                    }}
                  >
                    <div style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '0.75rem',
                      marginBottom: '0.75rem'
                    }}>
                      <div style={{
                        width: '32px',
                        height: '32px',
                        borderRadius: '8px',
                        backgroundColor: '#8b5cf6',
                        color: 'white',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: '14px',
                        fontWeight: '600',
                        flexShrink: 0
                      }}>
                        {index + 1}
                      </div>
                      <input
                        type="text"
                        value={step.title}
                        onChange={(e) => updateStep(step.id, 'title', e.target.value)}
                        placeholder="步骤标题"
                        style={{
                          flex: 1,
                          padding: '0.5rem',
                          border: '1px solid #e5e7eb',
                          borderRadius: '6px',
                          fontSize: '14px',
                          fontWeight: '500',
                          outline: 'none',
                          backgroundColor: 'white'
                        }}
                      />
                      <div style={{
                        display: 'flex',
                        gap: '0.25rem'
                      }}>
                        <button
                          onClick={() => moveStep(index, 'up')}
                          disabled={index === 0}
                          style={{
                            padding: '0.25rem 0.5rem',
                            backgroundColor: 'white',
                            border: '1px solid #e5e7eb',
                            borderRadius: '4px',
                            fontSize: '12px',
                            cursor: index === 0 ? 'not-allowed' : 'pointer',
                            opacity: index === 0 ? 0.5 : 1
                          }}
                        >
                          ↑
                        </button>
                        <button
                          onClick={() => moveStep(index, 'down')}
                          disabled={index === steps.length - 1}
                          style={{
                            padding: '0.25rem 0.5rem',
                            backgroundColor: 'white',
                            border: '1px solid #e5e7eb',
                            borderRadius: '4px',
                            fontSize: '12px',
                            cursor: index === steps.length - 1 ? 'not-allowed' : 'pointer',
                            opacity: index === steps.length - 1 ? 0.5 : 1
                          }}
                        >
                          ↓
                        </button>
                        <button
                          onClick={() => removeStep(step.id)}
                          style={{
                            padding: '0.25rem 0.5rem',
                            backgroundColor: 'white',
                            border: '1px solid #fee2e2',
                            borderRadius: '4px',
                            fontSize: '12px',
                            color: '#dc2626',
                            cursor: 'pointer'
                          }}
                        >
                          ✕
                        </button>
                      </div>
                    </div>
                    <textarea
                      value={step.description}
                      onChange={(e) => updateStep(step.id, 'description', e.target.value)}
                      placeholder="步骤详细描述（可选）"
                      rows={2}
                      style={{
                        width: '100%',
                        padding: '0.5rem',
                        border: '1px solid #e5e7eb',
                        borderRadius: '6px',
                        fontSize: '13px',
                        outline: 'none',
                        resize: 'vertical',
                        fontFamily: 'inherit',
                        backgroundColor: 'white'
                      }}
                    />
                  </div>
                ))}

                {steps.length === 0 && (
                  <div style={{
                    padding: '2rem',
                    textAlign: 'center',
                    color: '#9ca3af',
                    fontSize: '14px'
                  }}>
                    暂无步骤，点击"添加步骤"开始创建
                  </div>
                )}
              </div>
            </div>

            {/* 保存按钮区 */}
            <div style={{
              display: 'flex',
              gap: '1rem'
            }}>
              <button
                onClick={handleSave}
                style={{
                  flex: 1,
                  padding: '0.875rem',
                  backgroundColor: 'white',
                  color: '#6b7280',
                  border: '1px solid #e5e7eb',
                  borderRadius: '10px',
                  fontSize: '15px',
                  fontWeight: '600',
                  cursor: 'pointer',
                  transition: 'all 0.2s'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = '#f9fafb'
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = 'white'
                }}
              >
                保存草稿
              </button>
              <button
                onClick={handlePublish}
                disabled={!workflowName.trim() || steps.length === 0}
                style={{
                  flex: 1,
                  padding: '0.875rem',
                  background: workflowName.trim() && steps.length > 0
                    ? 'linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%)'
                    : '#e5e7eb',
                  color: workflowName.trim() && steps.length > 0 ? 'white' : '#9ca3af',
                  border: 'none',
                  borderRadius: '10px',
                  fontSize: '15px',
                  fontWeight: '600',
                  cursor: workflowName.trim() && steps.length > 0 ? 'pointer' : 'not-allowed',
                  transition: 'all 0.2s',
                  boxShadow: workflowName.trim() && steps.length > 0
                    ? '0 4px 12px rgba(139, 92, 246, 0.3)'
                    : 'none'
                }}
                onMouseEnter={(e) => {
                  if (workflowName.trim() && steps.length > 0) {
                    e.currentTarget.style.transform = 'translateY(-2px)'
                    e.currentTarget.style.boxShadow = '0 6px 20px rgba(139, 92, 246, 0.4)'
                  }
                }}
                onMouseLeave={(e) => {
                  if (workflowName.trim() && steps.length > 0) {
                    e.currentTarget.style.transform = 'translateY(0)'
                    e.currentTarget.style.boxShadow = '0 4px 12px rgba(139, 92, 246, 0.3)'
                  }
                }}
              >
                发布工作流
              </button>
            </div>
          </div>

          {/* 右侧：用户需求总结 */}
          <div>
            <div style={{
              backgroundColor: 'white',
              borderRadius: '16px',
              border: '1px solid #e5e7eb',
              padding: '1.5rem',
              boxShadow: '0 1px 3px rgba(0, 0, 0, 0.05)',
              position: 'sticky',
              top: '1rem'
            }}>
              <div style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.5rem',
                marginBottom: '1rem'
              }}>
                <span style={{ fontSize: '20px' }}>💡</span>
                <h3 style={{
                  fontSize: '1rem',
                  fontWeight: '600',
                  color: '#111827',
                  margin: 0
                }}>
                  需求总结
                </h3>
              </div>

              {userRequirement ? (
                <>
                  <div style={{
                    padding: '1rem',
                    backgroundColor: '#faf5ff',
                    borderRadius: '12px',
                    border: '1px solid #e9d5ff',
                    marginBottom: '1rem'
                  }}>
                    <div style={{
                      fontSize: '13px',
                      color: '#6b7280',
                      marginBottom: '0.5rem',
                      fontWeight: '500'
                    }}>
                      您的原始需求：
                    </div>
                    <div style={{
                      fontSize: '14px',
                      color: '#1f2937',
                      lineHeight: '1.6'
                    }}>
                      {userRequirement}
                    </div>
                  </div>

                  <div style={{
                    fontSize: '13px',
                    color: '#6b7280',
                    lineHeight: '1.6',
                    padding: '1rem',
                    backgroundColor: '#f9fafb',
                    borderRadius: '10px',
                    border: '1px solid #e5e7eb'
                  }}>
                    <p style={{ margin: '0 0 0.75rem 0' }}>
                      <strong style={{ color: '#374151' }}>💡 提示：</strong>
                    </p>
                    <ul style={{ margin: 0, paddingLeft: '1.25rem' }}>
                      <li style={{ marginBottom: '0.5rem' }}>
                        根据您的需求，我们已预填充了建议步骤
                      </li>
                      <li style={{ marginBottom: '0.5rem' }}>
                        您可以自由调整步骤顺序和内容
                      </li>
                      <li>
                        添加更多步骤以完善工作流
                      </li>
                    </ul>
                  </div>
                </>
              ) : (
                <div style={{
                  padding: '1rem',
                  textAlign: 'center',
                  color: '#9ca3af',
                  fontSize: '14px'
                }}>
                  暂无需求信息
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
