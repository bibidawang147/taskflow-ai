import { ChangeEvent, DragEvent, useMemo, useRef, useState } from 'react'
import { useNavigate, useParams, useLocation } from 'react-router-dom'

interface ToolOption {
  id: string
  name: string
  category: string
  icon: string
  color: string
  defaultModel: string
  description: string
  defaultPrompt: string
  defaultProviderId?: string
  recommendedModels?: string[]
}

interface ModelProvider {
  id: string
  name: string
  icon: string
  color: string
  description: string
  featuredModels: string[]
}

interface WorkflowNode {
  id: number
  name: string
  type: string
  icon: string
  color: string
  model?: string
  prompt?: string
  toolId?: string
  toolName?: string
  providerId?: string
  providerName?: string
  details?: string
  attachments?: File[]
}

const toolLibrary: ToolOption[] = [
  {
    id: 'requirement-analyzer',
    name: '需求分析助手',
    category: 'AI处理',
    icon: '分析',
    color: '#2563eb',
    defaultModel: 'GPT-4',
    description: '提取业务目标、目标用户和关键需求要点。',
    defaultPrompt: '请分析用户的需求，提取关键信息和目标。\n\n输入: {user_input}\n\n请输出:\n1. 核心需求\n2. 目标受众\n3. 内容类型\n4. 关键要点',
    defaultProviderId: 'openai',
    recommendedModels: ['GPT-4', 'Claude-3', 'Gemini-Pro']
  },
  {
    id: 'content-writer',
    name: '智能写作',
    category: 'AI处理',
    icon: '写作',
    color: '#10b981',
    defaultModel: 'GPT-4',
    description: '根据分析结果生成结构化的文章或文案内容。',
    defaultPrompt: '根据需求分析结果生成高质量文章内容。\n\n需求分析: {analysis_result}\n\n要求:\n- 结构清晰,逻辑连贯\n- 语言流畅,专业准确\n- 包含引言、正文、结论\n- 字数控制在800-1200字',
    defaultProviderId: 'openai',
    recommendedModels: ['GPT-4', 'GPT-3.5', 'Claude-3']
  },
  {
    id: 'seo-optimizer',
    name: 'SEO 优化器',
    category: '数据处理',
    icon: 'SEO',
    color: '#f59e0b',
    defaultModel: 'GPT-3.5',
    description: '为内容提炼关键词并生成 SEO 友好的结构。',
    defaultPrompt: '对文章进行SEO优化。\n\n文章内容: {article_content}\n\n优化项:\n1. 提取5-8个关键词\n2. 优化标题(包含主关键词)\n3. 添加meta描述(150-160字)\n4. 优化段落标题(H2, H3)',
    defaultProviderId: 'openai',
    recommendedModels: ['GPT-4', 'GPT-3.5']
  },
  {
    id: 'quality-check',
    name: '内容质检',
    category: 'AI处理',
    icon: '质检',
    color: '#8b5cf6',
    defaultModel: 'GPT-4',
    description: '对生成内容进行语法、逻辑、可读性与合规性检查。',
    defaultPrompt: '检测文章质量并提供改进建议。\n\n文章内容: {optimized_content}\n\n检测维度:\n1. 语法错误\n2. 逻辑连贯性\n3. 可读性评分\n4. SEO友好度\n5. 改进建议',
    defaultProviderId: 'openai',
    recommendedModels: ['GPT-4', 'Claude-3']
  },
  {
    id: 'image-enhance',
    name: '图像增强',
    category: '视觉处理',
    icon: '图像',
    color: '#8b5cf6',
    defaultModel: 'Stable Diffusion XL',
    description: '对上传的素材进行清晰度提升或风格化处理。',
    defaultPrompt: '请对上传的图片进行增强处理，提升清晰度，并生成两种风格化版本。',
    defaultProviderId: 'volcengine',
    recommendedModels: ['Stable Diffusion XL', 'Midjourney', 'DALL·E 3']
  },
  {
    id: 'video-editor',
    name: '视频剪辑助手',
    category: '视频处理',
    icon: '视频',
    color: '#3b82f6',
    defaultModel: 'Runway Gen-3',
    description: '对视频进行智能剪辑、字幕生成或镜头优化。',
    defaultPrompt: '根据上传的视频素材生成 60 秒的剪辑，并自动生成字幕和关键帧描述。',
    defaultProviderId: 'volcengine',
    recommendedModels: ['Runway Gen-3', 'Pika 1.0', 'Luma']
  }
]

const modelProviders: ModelProvider[] = [
  {
    id: 'openai',
    name: 'OpenAI',
    icon: 'O',
    color: '#2563eb',
    description: '适用于 GPT-4、GPT-4o、GPT-3.5 等通用文本与多模态任务。',
    featuredModels: ['GPT-4o', 'GPT-4 Turbo', 'GPT-3.5 Turbo']
  },
  {
    id: 'anthropic',
    name: 'Anthropic',
    icon: 'A',
    color: '#8b5cf6',
    description: 'Claude 系列模型擅长长文本理解与企业安全合规。',
    featuredModels: ['Claude 3 Opus', 'Claude 3 Sonnet', 'Claude 3 Haiku']
  },
  {
    id: 'wenxin',
    name: '文心',
    icon: '文',
    color: '#f97316',
    description: '百度文心系列在中文内容生成与企业知识库方面表现突出。',
    featuredModels: ['ERNIE-Bot 4.0', 'ERNIE Speed', 'ERNIE Lite']
  },
  {
    id: 'qwen',
    name: '千问',
    icon: '千',
    color: '#10b981',
    description: '阿里千问在代码、中文对话和行业知识问答方面能力均衡。',
    featuredModels: ['Qwen-Max', 'Qwen-Plus', 'Qwen-Turbo']
  },
  {
    id: 'volcengine',
    name: '火山引擎',
    icon: '火',
    color: '#ef4444',
    description: '火山方舟模型在多媒体生成、视频与图片处理上表现良好。',
    featuredModels: ['Skylark-Pro', 'Skylark-Turbo', 'Skylark-Lite']
  }
]

const allModelOptions = [
  'GPT-4',
  'GPT-3.5',
  'Claude-3',
  'Claude-2',
  'Gemini-Pro',
  'Stable Diffusion XL',
  'Midjourney',
  'DALL·E 3',
  'Runway Gen-3',
  'Pika 1.0',
  'Luma'
]

interface NewNodeConfig {
  toolId: string
  name: string
  model: string
  prompt: string
  providerId: string
  details: string
  attachments: File[]
}

export default function WorkflowDetailPage() {
  const navigate = useNavigate()
  const { id } = useParams()
  const location = useLocation()

  // 根据 ID 判断是新建还是编辑
  const isNewWorkflow = id === 'new'

  // 获取从搜索页传来的用户需求信息
  const userRequirement = location.state?.userRequirement || ''
  const suggestedSteps = location.state?.suggestedSteps || []

  // 模拟工作流节点数据
  const [nodes, setNodes] = useState<WorkflowNode[]>(() =>
    isNewWorkflow
      ? (suggestedSteps.length > 0
          ? suggestedSteps.map((stepTitle: string, index: number) => ({
              id: index + 1,
              name: stepTitle,
              type: 'AI处理',
              icon: 'AI',
              color: '#8b5cf6',
              model: 'GPT-4',
              prompt: `请完成"${stepTitle}"这个步骤。\n\n输入: {previous_output}\n\n要求: 请根据上一步的输出，完成当前步骤的任务。`,
              toolId: 'requirement-analyzer',
              toolName: '需求分析助手',
              providerId: 'openai',
              providerName: 'OpenAI',
              details: '',
              attachments: []
            }))
          : []) // 新建工作流时，如果有建议步骤就预填充，否则为空
      : [
          {
            id: 1,
            name: '需求分析',
            type: 'AI处理',
            icon: '分析',
            color: '#2563eb',
            model: 'GPT-4',
            prompt: toolLibrary[0]?.defaultPrompt,
            toolId: 'requirement-analyzer',
            toolName: '需求分析助手',
            providerId: toolLibrary[0]?.defaultProviderId,
            providerName: modelProviders.find(provider => provider.id === toolLibrary[0]?.defaultProviderId)?.name,
            details: '',
            attachments: []
          },
          {
            id: 2,
            name: '内容生成',
            type: 'AI处理',
            icon: '写作',
            color: '#10b981',
            model: 'GPT-4',
            prompt: toolLibrary[1]?.defaultPrompt,
            toolId: 'content-writer',
            toolName: '智能写作',
            providerId: toolLibrary[1]?.defaultProviderId,
            providerName: modelProviders.find(provider => provider.id === toolLibrary[1]?.defaultProviderId)?.name,
            details: '',
            attachments: []
          },
          {
            id: 3,
            name: 'SEO优化',
            type: '数据处理',
            icon: 'SEO',
            color: '#f59e0b',
            model: 'GPT-3.5',
            prompt: toolLibrary[2]?.defaultPrompt,
            toolId: 'seo-optimizer',
            toolName: 'SEO 优化器',
            providerId: toolLibrary[2]?.defaultProviderId,
            providerName: modelProviders.find(provider => provider.id === toolLibrary[2]?.defaultProviderId)?.name,
            details: '',
            attachments: []
          },
          {
            id: 4,
            name: '质量检测',
            type: 'AI处理',
            icon: '质检',
            color: '#8b5cf6',
            model: 'GPT-4',
            prompt: '检测文章质量并提供改进建议。\n\n文章内容: {optimized_content}\n\n检测维度:\n1. 语法错误\n2. 逻辑连贯性\n3. 可读性评分\n4. SEO友好度\n5. 改进建议',
            toolId: 'quality-check',
            toolName: '质量检测',
            providerId: toolLibrary[3]?.defaultProviderId,
            providerName: modelProviders.find(provider => provider.id === toolLibrary[3]?.defaultProviderId)?.name,
            details: '',
            attachments: []
          }
        ]
  )

  const [selectedNodeId, setSelectedNodeId] = useState<number | null>(null)
  const [previewResult, setPreviewResult] = useState<string>('等待执行工作流...')
  const [isEditingResult, setIsEditingResult] = useState<boolean>(false)
  const [editedResult, setEditedResult] = useState<string>('')
  const newNodeFileInputRef = useRef<HTMLInputElement>(null)
  const createDefaultNodeConfig = () => {
    const tool = toolLibrary[0]
    const fallbackProviderId = modelProviders[0]?.id ?? ''
    const providerId = tool?.defaultProviderId ?? fallbackProviderId
    const provider = modelProviders.find(entry => entry.id === providerId)
    const initialModel =
      provider?.featuredModels[0] ?? tool?.defaultModel ?? allModelOptions[0] ?? ''

    return {
      toolId: tool?.id ?? '',
      name: tool?.name ?? '',
      model: initialModel,
      prompt: tool?.defaultPrompt ?? '',
      providerId,
      details: '',
      attachments: []
    }
  }
  const [isAddingNode, setIsAddingNode] = useState(false)
  const [newNodeConfig, setNewNodeConfig] = useState<NewNodeConfig>(createDefaultNodeConfig)
  const toolMap = useMemo(() => {
    const map = new Map<string, ToolOption>()
    toolLibrary.forEach(tool => map.set(tool.id, tool))
    return map
  }, [])
  const providerMap = useMemo(() => {
    const map = new Map<string, ModelProvider>()
    modelProviders.forEach(provider => map.set(provider.id, provider))
    return map
  }, [])
  const findToolById = (toolId?: string) => (toolId ? toolMap.get(toolId) : undefined)
  const findProviderById = (providerId?: string) =>
    providerId ? providerMap.get(providerId) : undefined
  const defaultToolForNewNode = findToolById(newNodeConfig.toolId)
  const providerForNewNode = providerMap.get(newNodeConfig.providerId)
  const modelChoicesForNewNode = Array.from(
    new Set([
      ...(providerForNewNode?.featuredModels ?? []),
      ...(defaultToolForNewNode?.recommendedModels ?? []),
      ...(newNodeConfig.model ? [newNodeConfig.model] : [])
    ])
  )
  const effectiveModelChoicesForNewNode =
    modelChoicesForNewNode.length > 0 ? modelChoicesForNewNode : allModelOptions

  const selectedNode = nodes.find(n => n.id === selectedNodeId)

  // 计算当前选中节点的模型选项
  const selectedNodeTool = selectedNode ? findToolById(selectedNode.toolId) : undefined
  const selectedNodeProvider = selectedNode ? findProviderById(selectedNode.providerId) : undefined
  const toolRecommendedModels = selectedNodeTool?.recommendedModels ?? []
  const providerModels = selectedNodeProvider?.featuredModels ?? []
  const combinedModelChoices = Array.from(
    new Set([
      ...toolRecommendedModels,
      ...providerModels,
      ...(selectedNode?.model ? [selectedNode.model] : [])
    ])
  )
  const modelChoicesForCurrentNode =
    combinedModelChoices.length > 0 ? combinedModelChoices : allModelOptions

  const handleSelectNode = (nodeId: number) => {
    setSelectedNodeId(nodeId)
  }

  const handleRunWorkflow = () => {
    setPreviewResult('正在执行工作流...\n\n这是一个模拟结果预览。实际项目中，这里会显示工作流的执行结果。\n\n节点1: 需求分析完成\n- 核心需求: 生成技术文章\n- 目标受众: 开发者\n- 内容类型: 教程\n\n节点2: 内容生成中...')
    setIsEditingResult(false)
  }

  const handleApplyForSession = () => {
    // 临时应用工作流（仅在当前会话有效）
    // 保存当前工作流配置到 sessionStorage
    sessionStorage.setItem('currentWorkflow', JSON.stringify({
      id,
      nodes,
      timestamp: new Date().toISOString()
    }))
    alert('✅ 工作流已应用到当前会话！\n\n在本次会话中，您的配置将保持有效。关闭或刷新页面后，配置将被重置。')
  }

  const handleSaveToWorkspace = () => {
    // 永久保存工作流到工作区
    // 1. 保存当前配置到 localStorage
    const savedWorkflows = JSON.parse(localStorage.getItem('savedWorkflows') || '[]')
    const workflowToSave = {
      id: `workflow-${Date.now()}`,
      originalId: id,
      name: isNewWorkflow ? '新工作流' : `工作流副本 ${new Date().toLocaleString('zh-CN', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' })}`,
      nodes: nodes.map(node => ({ ...node })),
      createdAt: new Date().toISOString()
    }
    savedWorkflows.push(workflowToSave)
    localStorage.setItem('savedWorkflows', JSON.stringify(savedWorkflows))

    // 2. 同时应用到当前会话
    sessionStorage.setItem('currentWorkflow', JSON.stringify({
      id,
      nodes,
      timestamp: new Date().toISOString()
    }))

    alert('✅ 工作流已保存到我的工作流！\n\n您可以在工作区画布中找到这个工作流卡片。\n同时，当前会话也已应用此配置。')
  }

  const handleEditResult = () => {
    setEditedResult(previewResult)
    setIsEditingResult(true)
  }

  const handleSaveResult = () => {
    setPreviewResult(editedResult)
    setIsEditingResult(false)
  }

  const handleCancelEditResult = () => {
    setIsEditingResult(false)
    setEditedResult('')
  }

  const appendNewNodeFiles = (files: File[]) => {
    if (files.length === 0) return
    setNewNodeConfig(prev => {
      const seen = new Set(
        prev.attachments.map(file => `${file.name}-${file.size}-${file.lastModified}`)
      )
      const merged = [...prev.attachments]
      files.forEach(file => {
        const key = `${file.name}-${file.size}-${file.lastModified}`
        if (!seen.has(key)) {
          merged.push(file)
          seen.add(key)
        }
      })
      return {
        ...prev,
        attachments: merged
      }
    })
  }

  const handleNewNodeFileSelection = (event: ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files ?? [])
    appendNewNodeFiles(files)
    event.target.value = ''
  }

  const handleRemoveNewNodeAttachment = (index: number) => {
    setNewNodeConfig(prev => {
      const attachments = prev.attachments.filter((_, i) => i !== index)
      return { ...prev, attachments }
    })
  }

  const handleDropNewNodeFiles = (event: DragEvent<HTMLDivElement>) => {
    event.preventDefault()
    const files = Array.from(event.dataTransfer.files ?? [])
    appendNewNodeFiles(files)
  }

  const startAddingNode = () => {
    setNewNodeConfig(createDefaultNodeConfig())
    setIsAddingNode(true)
  }

  const handleCancelAddNode = () => {
    setIsAddingNode(false)
    setNewNodeConfig(createDefaultNodeConfig())
  }

  const handleNewNodeToolChange = (toolId: string) => {
    const tool = findToolById(toolId)
    if (!tool) return
    setNewNodeConfig(prev => {
      const nextProviderId = tool.defaultProviderId ?? prev.providerId
      const provider = providerMap.get(nextProviderId)
      const nextModel =
        tool.defaultModel ?? provider?.featuredModels[0] ?? prev.model
      return {
        ...prev,
        toolId: tool.id,
        name: tool.name,
        model: nextModel,
        prompt: tool.defaultPrompt ?? prev.prompt,
        providerId: nextProviderId
      }
    })
  }

  const handleNewNodeNameChange = (name: string) => {
    setNewNodeConfig(prev => ({ ...prev, name }))
  }

  const handleNewNodeModelChange = (model: string) => {
    setNewNodeConfig(prev => ({ ...prev, model }))
  }

  const handleNewNodePromptChange = (prompt: string) => {
    setNewNodeConfig(prev => ({ ...prev, prompt }))
  }

  const handleNewNodeProviderChange = (providerId: string) => {
    const provider = providerMap.get(providerId)
    setNewNodeConfig(prev => {
      const tool = findToolById(prev.toolId)
      const nextModel =
        provider?.featuredModels[0] ?? tool?.defaultModel ?? prev.model
      return {
        ...prev,
        providerId,
        model: nextModel
      }
    })
  }

  const handleNewNodeDetailsChange = (details: string) => {
    setNewNodeConfig(prev => ({ ...prev, details }))
  }

  const handleConfirmAddNode = () => {
    const tool = findToolById(newNodeConfig.toolId)
    const provider = findProviderById(newNodeConfig.providerId)

    const newId = nodes.length ? Math.max(...nodes.map(node => node.id)) + 1 : 1
    const name = newNodeConfig.name.trim() || tool?.name || `节点 ${newId}`
    const model =
      newNodeConfig.model.trim() ||
      tool?.defaultModel ||
      provider?.featuredModels[0] ||
      allModelOptions[0] ||
      ''
    const prompt = newNodeConfig.prompt.trim() || tool?.defaultPrompt || ''
    const details = newNodeConfig.details.trim()

    const newNode: WorkflowNode = {
      id: newId,
      name,
      type: tool?.category ?? '自定义',
      icon: tool?.icon ?? provider?.icon ?? '🤖',
      color: tool?.color ?? provider?.color ?? '#6366f1',
      model,
      prompt,
      toolId: tool?.id ?? 'custom-node',
      toolName: tool?.name ?? '自定义节点',
      providerId: newNodeConfig.providerId,
      providerName: provider?.name,
      details,
      attachments: [...newNodeConfig.attachments]
    }

    setNodes(prev => [...prev, newNode])
    setSelectedNodeId(newId)
    setEditingNode({ ...newNode })
    setIsAddingNode(false)
  }

  return (
    <div style={{ position: 'relative' }}>
      {isAddingNode && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            backgroundColor: 'rgba(15, 23, 42, 0.55)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '2rem',
            zIndex: 1000
          }}
        >
          <div
            style={{
              width: 'min(960px, 100%)',
              backgroundColor: '#ffffff',
              borderRadius: '24px',
              boxShadow: '0 40px 90px rgba(15, 23, 42, 0.35)',
              padding: '2rem',
              maxHeight: '90vh',
              overflowY: 'auto',
              display: 'flex',
              flexDirection: 'column',
              gap: '1.5rem'
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '1rem', flexWrap: 'wrap' }}>
              <div>
                <h2 style={{ margin: 0, fontSize: '1.35rem', fontWeight: 600, color: '#1f2937' }}>添加新的节点</h2>
                <p style={{ margin: '0.35rem 0 0', fontSize: '13px', color: '#6b7280', lineHeight: 1.6 }}>
                  选择要使用的工具与模型，系统会将节点固定在流程的末尾，你可以在添加后继续调整顺序与配置。
                </p>
              </div>
              <button
                onClick={handleCancelAddNode}
                style={{
                  border: 'none',
                  background: 'rgba(148, 163, 184, 0.12)',
                  color: '#475569',
                  borderRadius: '999px',
                  padding: '0.35rem 0.75rem',
                  fontSize: '13px',
                  cursor: 'pointer'
                }}
              >
                关闭
              </button>
            </div>

            <div>
              <label style={{ display: 'block', fontSize: '13px', fontWeight: 600, color: '#1f2937', marginBottom: '0.5rem' }}>
                节点要解决的问题（Prompt）
              </label>
              <textarea
                value={newNodeConfig.prompt}
                onChange={(event) => handleNewNodePromptChange(event.target.value)}
                placeholder="请描述这个节点的目标、输入信息，以及希望模型输出的格式。"
                style={{
                  width: '100%',
                  minHeight: '180px',
                  padding: '1rem',
                  borderRadius: '14px',
                  border: '1px solid #e2e8f0',
                  fontSize: '13px',
                  lineHeight: 1.6,
                  color: '#1f2937',
                  backgroundColor: '#f8fafc',
                  resize: 'vertical',
                  fontFamily: 'monospace'
                }}
              />
              <p style={{ margin: '0.5rem 0 0', fontSize: '11px', color: '#94a3b8' }}>
                建议写清楚输入上下文、处理目标和输出要求，便于模型准确完成任务。
              </p>
            </div>
            <div>
              <label style={{ display: 'block', fontSize: '13px', fontWeight: 600, color: '#1f2937', marginBottom: '0.75rem' }}>
                模型品牌
              </label>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1rem' }}>
                {modelProviders.map(provider => {
                  const isSelected = provider.id === newNodeConfig.providerId
                  return (
                    <div
                      key={provider.id}
                      onClick={() => handleNewNodeProviderChange(provider.id)}
                      style={{
                        border: `2px solid ${isSelected ? provider.color : 'rgba(203, 213, 225, 0.6)'}`,
                        backgroundColor: isSelected ? `${provider.color}10` : '#ffffff',
                        borderRadius: '16px',
                        padding: '1.1rem',
                        cursor: 'pointer',
                        transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                        boxShadow: isSelected
                          ? `0 20px 40px -10px ${provider.color}35, 0 10px 20px -8px ${provider.color}25, 0 0 0 1px ${provider.color}15`
                          : '0 8px 16px -4px rgba(15, 23, 42, 0.12), 0 4px 8px -2px rgba(15, 23, 42, 0.08)',
                        transform: isSelected ? 'translateY(-4px) scale(1.02)' : 'translateY(0) scale(1)'
                      }}
                      onMouseEnter={(e) => {
                        if (!isSelected) {
                          e.currentTarget.style.boxShadow = '0 12px 24px -6px rgba(15, 23, 42, 0.18), 0 6px 12px -3px rgba(15, 23, 42, 0.12)'
                          e.currentTarget.style.transform = 'translateY(-3px) scale(1.01)'
                        }
                      }}
                      onMouseLeave={(e) => {
                        if (!isSelected) {
                          e.currentTarget.style.boxShadow = '0 8px 16px -4px rgba(15, 23, 42, 0.12), 0 4px 8px -2px rgba(15, 23, 42, 0.08)'
                          e.currentTarget.style.transform = 'translateY(0) scale(1)'
                        }
                      }}
                    >
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '0.75rem' }}>
                        <div style={{
                          width: '42px',
                          height: '42px',
                          borderRadius: '12px',
                          backgroundColor: `${provider.color}20`,
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          fontSize: '1.25rem'
                        }}>
                          {provider.icon}
                        </div>
                        <div>
                          <div style={{ fontSize: '0.95rem', fontWeight: 600, color: '#1f2937' }}>{provider.name}</div>
                          <div style={{ fontSize: '11px', color: '#64748b' }}>热门模型：{provider.featuredModels.slice(0, 2).join('、')}</div>
                        </div>
                      </div>
                      <p style={{ margin: 0, fontSize: '12px', color: '#475569', lineHeight: 1.6 }}>
                        {provider.description}
                      </p>
                    </div>
                  )
                })}
              </div>
            </div>

            <div
              style={{
                display: 'flex',
                flexWrap: 'wrap',
                gap: '1.5rem',
                width: '100%'
              }}
            >
              <div
                style={{
                  flex: '1 1 280px',
                  minWidth: '0'
                }}
              >
                <label style={{ display: 'block', fontSize: '13px', fontWeight: 600, color: '#1f2937', marginBottom: '0.5rem' }}>
                  节点名称
                </label>
                <input
                  value={newNodeConfig.name}
                  onChange={(event) => handleNewNodeNameChange(event.target.value)}
                  placeholder="为节点起一个易识别的名称"
                  style={{
                    width: '100%',
                    padding: '0.75rem 1rem',
                    borderRadius: '12px',
                    border: '1px solid #e2e8f0',
                    fontSize: '14px',
                    color: '#1f2937',
                    backgroundColor: '#ffffff'
                  }}
                />
                <p style={{ margin: '0.5rem 0 0', fontSize: '11px', color: '#94a3b8' }}>
                  默认使用模板名称，可根据节点职责自定义。
                </p>
              </div>
              <div
                style={{
                  flex: '1 1 280px',
                  minWidth: '0'
                }}
              >
                <label style={{ display: 'block', fontSize: '13px', fontWeight: 600, color: '#1f2937', marginBottom: '0.5rem' }}>
                  模型选择
                </label>
                <select
                  value={newNodeConfig.model}
                  onChange={(event) => handleNewNodeModelChange(event.target.value)}
                  style={{
                    width: '100%',
                    padding: '0.75rem 1rem',
                    borderRadius: '12px',
                    border: '1px solid #e2e8f0',
                    fontSize: '14px',
                    color: '#1f2937',
                    backgroundColor: '#ffffff',
                    cursor: 'pointer'
                  }}
                >
                  {effectiveModelChoicesForNewNode.map(model => (
                    <option key={model} value={model}>
                      {model}
                    </option>
                  ))}
                </select>
                <p style={{ margin: '0.5rem 0 0', fontSize: '11px', color: '#94a3b8' }}>
                  推荐模型会根据品牌与模板自动匹配，也可以手动调整。
                </p>
              </div>
            </div>

            <div>
              <label style={{ display: 'block', fontSize: '13px', fontWeight: 600, color: '#1f2937', marginBottom: '0.5rem' }}>
                补充说明与上下文（可选）
              </label>
              <textarea
                value={newNodeConfig.details}
                onChange={(event) => handleNewNodeDetailsChange(event.target.value)}
                placeholder="例如：告诉模型参考哪些资料、使用什么语气、产出格式或关键注意事项…"
                style={{
                  width: '100%',
                  minHeight: '140px',
                  padding: '1rem',
                  borderRadius: '14px',
                  border: '1px solid #e2e8f0',
                  fontSize: '13px',
                  lineHeight: 1.6,
                  color: '#1f2937',
                  backgroundColor: '#f8fafc',
                  resize: 'vertical'
                }}
              />
            </div>

            <div>
              <label style={{ display: 'block', fontSize: '13px', fontWeight: 600, color: '#1f2937', marginBottom: '0.5rem' }}>
                参考附件（可选）
              </label>
              <div
                onClick={() => newNodeFileInputRef.current?.click()}
                onDragOver={(event) => {
                  event.preventDefault()
                  event.dataTransfer.dropEffect = 'copy'
                }}
                onDrop={handleDropNewNodeFiles}
                style={{
                  padding: '0.9rem',
                  borderRadius: '12px',
                  border: '1px dashed rgba(79, 70, 229, 0.45)',
                  backgroundColor: '#f5f3ff',
                  color: '#4338ca',
                  textAlign: 'center',
                  fontSize: '13px',
                  fontWeight: 500,
                  cursor: 'pointer',
                  transition: 'all 0.2s ease'
                }}
                onMouseEnter={(event) => {
                  event.currentTarget.style.backgroundColor = '#ede9fe'
                  event.currentTarget.style.borderColor = '#6366f1'
                }}
                onMouseLeave={(event) => {
                  event.currentTarget.style.backgroundColor = '#f5f3ff'
                  event.currentTarget.style.borderColor = 'rgba(79, 70, 229, 0.45)'
                }}
              >
                点击或拖拽文件到这里上传，支持图片、视频、音频与文档。
              </div>
              <input
                ref={newNodeFileInputRef}
                type="file"
                accept="image/*,video/*,audio/*,.pdf,.doc,.docx,.ppt,.pptx,.txt"
                multiple
                onChange={handleNewNodeFileSelection}
                style={{ display: 'none' }}
              />

              {newNodeConfig.attachments.length > 0 && (
                <div style={{ marginTop: '0.75rem', display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                  <p style={{ margin: 0, fontSize: '12px', color: '#6b7280' }}>
                    已添加 {newNodeConfig.attachments.length} 个附件：
                  </p>
                  <div style={{
                    maxHeight: '140px',
                    overflowY: 'auto',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '0.5rem'
                  }}>
                    {newNodeConfig.attachments.map((file, index) => (
                      <div
                        key={`${file.name}-${file.size}-${file.lastModified}-${index}`}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'space-between',
                          padding: '0.5rem 0.75rem',
                          borderRadius: '10px',
                          border: '1px solid rgba(79, 70, 229, 0.12)',
                          backgroundColor: '#faf5ff',
                          fontSize: '12px',
                          color: '#4338ca'
                        }}
                      >
                        <span style={{ flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', paddingRight: '0.5rem' }}>
                          {file.name}
                        </span>
                        <button
                          onClick={() => handleRemoveNewNodeAttachment(index)}
                          style={{
                            border: 'none',
                            background: 'transparent',
                            color: '#7c3aed',
                            fontSize: '12px',
                            cursor: 'pointer',
                            fontWeight: 600
                          }}
                        >
                          移除
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem', gap: '0.5rem', flexWrap: 'wrap' }}>
                <label style={{ fontSize: '13px', fontWeight: 600, color: '#1f2937' }}>
                  节点模板（可选）
                </label>
                <span style={{ fontSize: '11px', color: '#94a3b8' }}>
                  选择模板可快速填充 Prompt 与推荐模型，也可保持自定义设置。
                </span>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1rem' }}>
                {toolLibrary.map(tool => {
                  const isSelected = tool.id === newNodeConfig.toolId
                  return (
                    <div
                      key={tool.id}
                      onClick={() => handleNewNodeToolChange(tool.id)}
                      style={{
                        border: `2px solid ${isSelected ? tool.color : 'rgba(203, 213, 225, 0.6)'}`,
                        backgroundColor: isSelected ? `${tool.color}10` : '#ffffff',
                        borderRadius: '16px',
                        padding: '1.1rem',
                        cursor: 'pointer',
                        transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                        boxShadow: isSelected
                          ? `0 20px 40px -10px ${tool.color}35, 0 10px 20px -8px ${tool.color}25, 0 0 0 1px ${tool.color}15`
                          : '0 8px 16px -4px rgba(15, 23, 42, 0.12), 0 4px 8px -2px rgba(15, 23, 42, 0.08)',
                        transform: isSelected ? 'translateY(-4px) scale(1.02)' : 'translateY(0) scale(1)'
                      }}
                      onMouseEnter={(e) => {
                        if (!isSelected) {
                          e.currentTarget.style.boxShadow = '0 12px 24px -6px rgba(15, 23, 42, 0.18), 0 6px 12px -3px rgba(15, 23, 42, 0.12)'
                          e.currentTarget.style.transform = 'translateY(-3px) scale(1.01)'
                        }
                      }}
                      onMouseLeave={(e) => {
                        if (!isSelected) {
                          e.currentTarget.style.boxShadow = '0 8px 16px -4px rgba(15, 23, 42, 0.12), 0 4px 8px -2px rgba(15, 23, 42, 0.08)'
                          e.currentTarget.style.transform = 'translateY(0) scale(1)'
                        }
                      }}
                    >
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '0.75rem' }}>
                        <div style={{
                          width: '42px',
                          height: '42px',
                          borderRadius: '12px',
                          backgroundColor: `${tool.color}20`,
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          fontSize: '1.25rem'
                        }}>
                          {tool.icon}
                        </div>
                        <div>
                          <div style={{ fontSize: '11px', color: '#64748b' }}>{tool.category}</div>
                        </div>
                      </div>
                      <p style={{ margin: 0, fontSize: '12px', color: '#475569', lineHeight: 1.6 }}>
                        {tool.description}
                      </p>
                    </div>
                  )
                })}
              </div>
            </div>

            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
              <p style={{ margin: 0, fontSize: '12px', color: '#6b7280' }}>
                新节点会插入到流程末尾，稍后可拖拽调整顺序。
              </p>
              <div style={{ display: 'flex', gap: '0.75rem' }}>
                <button
                  onClick={handleCancelAddNode}
                  style={{
                    padding: '0.65rem 1.4rem',
                    borderRadius: '999px',
                    border: '1px solid #e2e8f0',
                    backgroundColor: '#ffffff',
                    color: '#475569',
                    fontSize: '13px',
                    fontWeight: 500,
                    cursor: 'pointer'
                  }}
                >
                  取消
                </button>
                <button
                  onClick={handleConfirmAddNode}
                  style={{
                    padding: '0.65rem 1.6rem',
                    borderRadius: '999px',
                    border: 'none',
                    backgroundColor: '#6366f1',
                    color: '#ffffff',
                    fontSize: '13px',
                    fontWeight: 600,
                    cursor: 'pointer',
                    boxShadow: '0 18px 30px rgba(99, 102, 241, 0.3)'
                  }}
                >
                  确认添加
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      <div style={{
        height: 'calc(100vh - 64px)',
        display: 'flex',
        flexDirection: 'row',
        overflow: 'hidden',
        backgroundColor: '#f9fafb'
    }}>
      {/* 左侧节点列表 */}
      <div style={{
        flex: selectedNodeId ? '0 0 280px' : 1,
        borderRight: '1px solid #e5e7eb',
        backgroundColor: 'white',
        display: 'flex',
        flexDirection: 'column',
        overflow: 'hidden',
        transition: 'flex 0.3s'
      }}>
        {/* 头部 */}
        <div style={{
          padding: '1.5rem 1rem',
          borderBottom: '1px solid #e5e7eb'
        }}>
          <button
            onClick={() => navigate(-1)}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem',
              padding: '0.5rem 0.75rem',
              backgroundColor: '#f3f4f6',
              border: 'none',
              borderRadius: '8px',
              fontSize: '14px',
              color: '#6b7280',
              cursor: 'pointer',
              marginBottom: '1rem',
              fontWeight: '500'
            }}
          >
            ← 返回
          </button>
          <h2 style={{
            fontSize: '1.25rem',
            fontWeight: '600',
            color: '#1f2937',
            margin: '0 0 0.5rem 0'
          }}>
            {isNewWorkflow ? '新建工作流' : '工作流节点'}
          </h2>
          <p style={{
            fontSize: '13px',
            color: '#6b7280',
            margin: 0
          }}>
            {isNewWorkflow ? '开始创建你的工作流' : `共 ${nodes.length} 个节点`}
          </p>
          <div style={{ marginTop: '1rem' }}>
            <button
              onClick={startAddingNode}
              style={{
                width: '100%',
                padding: '0.65rem 0.9rem',
                backgroundColor: '#eef2ff',
                color: '#4338ca',
                border: '1px dashed rgba(99, 102, 241, 0.35)',
                borderRadius: '10px',
                fontSize: '13px',
                fontWeight: 600,
                cursor: 'pointer',
                transition: 'all 0.2s'
              }}
              onMouseEnter={(event) => {
                event.currentTarget.style.backgroundColor = '#e0e7ff'
                event.currentTarget.style.borderColor = '#6366f1'
              }}
              onMouseLeave={(event) => {
                event.currentTarget.style.backgroundColor = '#eef2ff'
                event.currentTarget.style.borderColor = 'rgba(99, 102, 241, 0.35)'
              }}
            >
              添加节点
            </button>
          </div>
        </div>

        {/* 节点列表 */}
        <div style={{
          flex: 1,
          overflowY: 'auto',
          padding: '1rem'
        }}>
          {isNewWorkflow && nodes.length === 0 ? (
            <div style={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              padding: '3rem 1rem',
              textAlign: 'center',
              color: '#9ca3af'
            }}>
              <p style={{ fontSize: '14px', marginBottom: '1rem' }}>还没有添加任何节点</p>
              <button
                onClick={startAddingNode}
                style={{
                  padding: '0.75rem 1.5rem',
                  backgroundColor: '#8b5cf6',
                  color: 'white',
                  border: 'none',
                  borderRadius: '8px',
                  fontSize: '14px',
                  fontWeight: '500',
                  cursor: 'pointer'
                }}
              >
                添加第一个节点
              </button>
            </div>
          ) : (
            <div style={{
              display: 'flex',
              flexDirection: 'column',
              gap: '0.75rem'
            }}>
              {nodes.map((node, index) => (
              <div key={node.id}>
                <div
                  onClick={() => handleSelectNode(node.id)}
                  onDoubleClick={(e) => {
                    e.preventDefault()
                    handleEditNode(node)
                  }}
                  style={{
                    padding: '1rem',
                    backgroundColor: selectedNodeId === node.id ? `${node.color}10` : 'white',
                    border: `2px solid ${selectedNodeId === node.id ? node.color : '#e5e7eb'}`,
                    borderRadius: '12px',
                    cursor: 'pointer',
                    transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                    boxShadow: selectedNodeId === node.id
                      ? `0 10px 25px -5px ${node.color}40, 0 8px 10px -6px ${node.color}30, 0 0 0 1px ${node.color}10`
                      : '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -2px rgba(0, 0, 0, 0.1)',
                    transform: selectedNodeId === node.id ? 'translateY(-2px)' : 'translateY(0)',
                    userSelect: 'none'
                  }}
                  onMouseEnter={(e) => {
                    if (selectedNodeId !== node.id) {
                      e.currentTarget.style.borderColor = `${node.color}40`
                      e.currentTarget.style.backgroundColor = `${node.color}05`
                      e.currentTarget.style.boxShadow = `0 10px 20px -5px rgba(0, 0, 0, 0.15), 0 6px 8px -4px rgba(0, 0, 0, 0.1)`
                      e.currentTarget.style.transform = 'translateY(-2px)'
                    }
                  }}
                  onMouseLeave={(e) => {
                    if (selectedNodeId !== node.id) {
                      e.currentTarget.style.borderColor = '#e5e7eb'
                      e.currentTarget.style.backgroundColor = 'white'
                      e.currentTarget.style.boxShadow = '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -2px rgba(0, 0, 0, 0.1)'
                      e.currentTarget.style.transform = 'translateY(0)'
                    }
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                    <div style={{
                      width: '40px',
                      height: '40px',
                      backgroundColor: `${node.color}20`,
                      borderRadius: '10px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: '20px',
                      flexShrink: 0
                    }}>
                      {node.icon}
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{
                        fontSize: '14px',
                        fontWeight: '600',
                        color: '#1f2937',
                        marginBottom: '0.25rem'
                      }}>
                        {index + 1}. {node.name}
                      </div>
                      <div style={{
                        fontSize: '11px',
                        color: '#6b7280'
                      }}>
                        {node.type}
                      </div>
                      {node.providerName && (
                        <div style={{
                          fontSize: '11px',
                          color: '#475569',
                          fontWeight: 500,
                          marginTop: '0.2rem'
                        }}>
                          模型品牌：{node.providerName}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                {index < nodes.length - 1 && (
                  <div style={{
                    display: 'flex',
                    justifyContent: 'center',
                    margin: '0.5rem 0'
                  }}>
                    <div style={{
                      color: '#d1d5db',
                      fontSize: '18px'
                    }}>
                      ↓
                    </div>
                  </div>
                )}
              </div>
              ))}
            </div>
          )}
        </div>

        {/* 底部操作按钮 */}
        <div style={{
          padding: '1rem',
          borderTop: '1px solid #e5e7eb'
        }}>
          <button
            onClick={handleRunWorkflow}
            style={{
              width: '100%',
              padding: '0.75rem',
              backgroundColor: '#8b5cf6',
              color: 'white',
              border: 'none',
              borderRadius: '8px',
              fontSize: '14px',
              fontWeight: '500',
              cursor: 'pointer',
              marginBottom: '0.5rem'
            }}
          >
            运行工作流
          </button>
          <button
            onClick={handleApplyForSession}
            style={{
              width: '100%',
              padding: '0.75rem',
              backgroundColor: '#3b82f6',
              color: 'white',
              border: 'none',
              borderRadius: '8px',
              fontSize: '14px',
              fontWeight: '500',
              cursor: 'pointer',
              marginBottom: '0.5rem'
            }}
          >
            本次工作应用此工作流
          </button>
          <button
            onClick={handleSaveToWorkspace}
            style={{
              width: '100%',
              padding: '0.75rem',
              backgroundColor: 'white',
              color: '#10b981',
              border: '2px solid #10b981',
              borderRadius: '8px',
              fontSize: '14px',
              fontWeight: '600',
              cursor: 'pointer'
            }}
          >
            应用修改到我的工作流
          </button>
        </div>
      </div>

      {/* 中间编辑区域 */}
      <div
        onWheel={(e) => {
          // 阻止滚动事件冒泡，防止影响左右面板
          e.stopPropagation()
        }}
        style={{
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        overflowY: 'auto',
        backgroundColor: 'white',
        transition: 'flex 0.3s'
      }}>
        {!selectedNode ? (
          <div style={{
            flex: 1,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '2rem',
            color: '#6b7280'
          }}>
            {/* 用户需求显示区域 */}
            {isNewWorkflow && userRequirement && (
              <div style={{
                marginBottom: '1.5rem',
                padding: '1rem 1.25rem',
                backgroundColor: '#faf5ff',
                borderRadius: '12px',
                border: '1px solid #e9d5ff',
                maxWidth: '500px'
              }}>
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.5rem',
                  marginBottom: '0.5rem'
                }}>
                  <span style={{
                    fontSize: '13px',
                    fontWeight: '600',
                    color: '#6d28d9'
                  }}>
                    您的需求
                  </span>
                </div>
                <p style={{
                  fontSize: '14px',
                  color: '#1f2937',
                  lineHeight: '1.6',
                  margin: 0
                }}>
                  {userRequirement}
                </p>
              </div>
            )}

            <h2 style={{
              fontSize: '1.5rem',
              fontWeight: '600',
              color: '#1f2937',
              marginBottom: '0.5rem'
            }}>
              {isNewWorkflow ? '创建新的工作流' : 'AI文章生成工作流'}
            </h2>
            <p style={{
              fontSize: '14px',
              color: '#6b7280',
              textAlign: 'center',
              maxWidth: '400px',
              lineHeight: '1.6'
            }}>
              {isNewWorkflow
                ? (userRequirement
                    ? '根据您的需求，我们已经为您预填充了建议步骤。您可以直接使用或根据需要调整。'
                    : '开始构建你的 AI 工作流。点击左侧"添加第一个节点"按钮开始。')
                : '这是一个智能文章生成工作流,包含需求分析、内容生成、SEO优化和质量检测四个步骤。'}
              <br /><br />
              {!isNewWorkflow && '点击左侧节点查看详情和编辑配置。'}
            </p>
          </div>
        ) : selectedNode && (
          <>
            {/* 节点标题 */}
            <div
              style={{
                padding: '1.5rem 2rem',
                borderBottom: '1px solid #e5e7eb',
                backgroundColor: 'white'
              }}
            >
              <div
                style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1rem' }}
              >
                <div style={{
                  width: '56px',
                  height: '56px',
                  backgroundColor: `${selectedNode.color}20`,
                  borderRadius: '12px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '28px'
                }}>
                  {selectedNode.icon}
                </div>
                <div>
                  <h2 style={{
                    fontSize: '1.5rem',
                    fontWeight: '600',
                    color: '#1f2937',
                    margin: '0 0 0.25rem 0'
                  }}>
                    {selectedNode.name}
                  </h2>
                  <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
                    <span style={{
                      fontSize: '12px',
                      backgroundColor: `${selectedNode.color}20`,
                      color: selectedNode.color,
                      padding: '4px 8px',
                      borderRadius: '6px',
                      fontWeight: '500'
                    }}>
                      {selectedNode.type}
                    </span>
                    <span style={{
                      fontSize: '12px',
                      color: '#6b7280'
                    }}>
                      节点 {selectedNode.id}
                    </span>
                    {selectedNode.providerName && (
                      <span style={{
                        fontSize: '12px',
                        backgroundColor: '#e0f2fe',
                        color: '#0ea5e9',
                        padding: '4px 8px',
                        borderRadius: '6px',
                        fontWeight: '500'
                      }}>
                        {selectedNode.providerName}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* 编辑内容 */}
            <div style={{
              flex: 1,
              overflowY: 'auto',
              padding: '2rem'
            }}>
              {/* 节点 Prompt */}
              <div style={{ marginBottom: '2rem' }}>
                <label style={{
                  display: 'block',
                  fontSize: '14px',
                  fontWeight: '600',
                  color: '#1f2937',
                  marginBottom: '0.5rem'
                }}>
                  节点要解决的问题（Prompt）
                </label>
                <p style={{ margin: '0 0 0.75rem', fontSize: '12px', color: '#6b7280', lineHeight: 1.6 }}>
                  描述节点输入、目标和期望输出形式，帮助模型精准理解任务。
                </p>
                <textarea
                  value={selectedNode.prompt ?? ''}
                  onChange={(event) => {
                    setNodes(prev =>
                      prev.map(node =>
                        node.id === selectedNode.id
                          ? { ...node, prompt: event.target.value }
                          : node
                      )
                    )
                  }}
                  placeholder="请输入节点 Prompt，例如说明输入格式、处理目标和输出结构……"
                  style={{
                    width: '100%',
                    minHeight: '280px',
                    padding: '1rem',
                    borderRadius: '12px',
                    border: '1px solid #e2e8f0',
                    fontSize: '13px',
                    lineHeight: 1.6,
                    fontFamily: 'monospace',
                    backgroundColor: '#ffffff',
                    color: '#1f2937',
                    resize: 'vertical'
                  }}
                />
                <div style={{ marginTop: '0.5rem', fontSize: '12px', color: '#6b7280' }}>
                  提示：建议使用 {'{变量名}'} 引用上一步输出，或明确列出检查项。
                </div>
              </div>

              {/* 模型选择 */}
              <div style={{ marginBottom: '2rem' }}>
                <label style={{ display: 'block', fontSize: '13px', fontWeight: 600, color: '#1f2937', marginBottom: '0.5rem' }}>
                  模型选择
                </label>
                <select
                  value={selectedNode.model ?? ''}
                  onChange={(event) => {
                    setNodes(prev =>
                      prev.map(node =>
                        node.id === selectedNode.id
                          ? { ...node, model: event.target.value }
                          : node
                      )
                    )
                  }}
                  style={{
                    width: '100%',
                    padding: '0.75rem 1rem',
                    borderRadius: '12px',
                    border: '1px solid #e2e8f0',
                    fontSize: '14px',
                    color: '#1f2937',
                    backgroundColor: '#ffffff',
                    cursor: 'pointer'
                  }}
                >
                  {modelChoicesForCurrentNode.map(model => (
                    <option key={model} value={model}>
                      {model}
                    </option>
                  ))}
                </select>
                <p style={{ margin: '0.5rem 0 0', fontSize: '11px', color: '#94a3b8' }}>
                  推荐模型会根据品牌与模板自动匹配，也可以手动调整。
                </p>
              </div>

            </div>
          </>
        )}
      </div>

      {/* 右侧预览区域 */}
      <div style={{
        flex: selectedNodeId ? (isEditingResult ? '0 0 600px' : '0 0 400px') : 1,
        borderLeft: '1px solid #e5e7eb',
        backgroundColor: 'white',
        display: 'flex',
        flexDirection: 'column',
        overflow: 'hidden',
        transition: 'flex 0.3s'
      }}>
        {/* 预览头部 */}
        <div style={{
          padding: '1.5rem 1.5rem',
          borderBottom: '1px solid #e5e7eb'
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.5rem' }}>
            <h3 style={{
              fontSize: '1.125rem',
              fontWeight: '600',
              color: '#1f2937',
              margin: 0
            }}>
              结果预览
            </h3>
            {!isEditingResult ? (
              <button
                onClick={handleEditResult}
                disabled={previewResult === '等待执行工作流...'}
                style={{
                  padding: '0.5rem 1rem',
                  backgroundColor: previewResult === '等待执行工作流...' ? '#f3f4f6' : '#8b5cf615',
                  color: previewResult === '等待执行工作流...' ? '#9ca3af' : '#8b5cf6',
                  border: 'none',
                  borderRadius: '6px',
                  fontSize: '13px',
                  fontWeight: '500',
                  cursor: previewResult === '等待执行工作流...' ? 'not-allowed' : 'pointer'
                }}
              >
                编辑结果
              </button>
            ) : (
              <div style={{ display: 'flex', gap: '0.5rem' }}>
                <button
                  onClick={handleCancelEditResult}
                  style={{
                    padding: '0.5rem 1rem',
                    backgroundColor: '#f3f4f6',
                    color: '#6b7280',
                    border: 'none',
                    borderRadius: '6px',
                    fontSize: '13px',
                    fontWeight: '500',
                    cursor: 'pointer'
                  }}
                >
                  取消
                </button>
                <button
                  onClick={handleSaveResult}
                  style={{
                    padding: '0.5rem 1rem',
                    backgroundColor: '#8b5cf6',
                    color: 'white',
                    border: 'none',
                    borderRadius: '6px',
                    fontSize: '13px',
                    fontWeight: '500',
                    cursor: 'pointer'
                  }}
                >
                  保存
                </button>
              </div>
            )}
          </div>
          <p style={{
            fontSize: '13px',
            color: '#6b7280',
            margin: 0
          }}>
            {isEditingResult ? '编辑工作流执行结果' : '运行工作流查看结果'}
          </p>
        </div>

        {/* 预览内容 */}
        <div style={{
          flex: 1,
          overflowY: 'auto',
          padding: '1.5rem'
        }}>
          {!isEditingResult ? (
            <div style={{
              backgroundColor: '#f9fafb',
              border: '1px solid #e5e7eb',
              borderRadius: '12px',
              padding: '1.5rem',
              minHeight: '200px'
            }}>
              <pre style={{
                fontSize: '13px',
                lineHeight: '1.6',
                color: '#1f2937',
                margin: 0,
                whiteSpace: 'pre-wrap',
                fontFamily: 'monospace'
              }}>
                {previewResult}
              </pre>
            </div>
          ) : (
            <textarea
              value={editedResult}
              onChange={(e) => setEditedResult(e.target.value)}
              style={{
                width: '100%',
                minHeight: '400px',
                padding: '1.5rem',
                border: '1px solid #e5e7eb',
                borderRadius: '12px',
                fontSize: '13px',
                lineHeight: '1.6',
                fontFamily: 'monospace',
                backgroundColor: 'white',
                color: '#1f2937',
                resize: 'vertical',
                outline: 'none'
              }}
              placeholder="编辑工作流执行结果..."
            />
          )}

          {/* 执行历史 */}
          <div style={{ marginTop: '1.5rem' }}>
            <h4 style={{
              fontSize: '14px',
              fontWeight: '600',
              color: '#1f2937',
              margin: '0 0 0.75rem 0'
            }}>
              执行历史
            </h4>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
              {[
                { time: '10:30', status: '成功', duration: '2.3s' },
                { time: '09:15', status: '成功', duration: '1.8s' },
                { time: '昨天', status: '失败', duration: '0.5s' }
              ].map((record, index) => (
                <div
                  key={index}
                  style={{
                    padding: '0.75rem',
                    backgroundColor: 'white',
                    border: '1px solid #e5e7eb',
                    borderRadius: '8px',
                    fontSize: '12px'
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.25rem' }}>
                    <span style={{ color: '#6b7280' }}>{record.time}</span>
                    <span style={{
                      color: record.status === '成功' ? '#10b981' : '#ef4444',
                      fontWeight: '500'
                    }}>
                      {record.status}
                    </span>
                  </div>
                  <div style={{ color: '#9ca3af', fontSize: '11px' }}>
                    耗时: {record.duration}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
    </div>
  )
}
