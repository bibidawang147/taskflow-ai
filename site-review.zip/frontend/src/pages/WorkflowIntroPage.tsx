import { useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import WorkflowFlowChart from '../components/WorkflowFlowChart'
import '../styles/intro-pages.css'

// 模拟数据
const workflowData = {
  id: '1',
  title: '编辑动画图片',
  icon: '',
  description: '为静态图片添加动画效果，输出 GIF 或视频',

  // 核心介绍
  overview: '基于AI技术的智能动画生成工具，帮助设计师和内容创作者快速将静态图片转换为专业级动画效果。无需复杂的动画制作经验，通过简单的参数设置即可生成高质量的GIF和视频动画，大幅提升工作效率。',
  tags: ['AI驱动', '自动化', '高效率', '零代码'],

  author: {
    name: '张小明',
    avatar: '',
    badges: ['高级创作者', '认证专家'],
    followers: 1250
  },
  rating: 4.8,
  ratingCount: 156,
  usageCount: 3420,
  categories: ['图像处理', '动画制作', '创意工具'],

  useCases: [
    {
      title: '产品展示动画',
      description: '将静态产品图转换为360度旋转展示动画',
      image: '',
      tags: ['电商', '产品']
    },
    {
      title: '营销海报动效',
      description: '为促销海报添加闪烁、缩放等吸引眼球的动画效果',
      image: '',
      tags: ['营销', '广告']
    },
    {
      title: 'Logo动画',
      description: '为品牌Logo添加入场动画效果',
      image: '',
      tags: ['品牌', 'Logo']
    }
  ],

  steps: [
    {
      id: 'step-1',
      number: 1,
      title: 'AI 模型配置',
      description: '配置AI模型参数和提示词',
      icon: '',
      parameters: [
        {
          name: 'AI 品牌',
          description: '选择使用的AI服务提供商',
          required: true,
          type: 'select',
          defaultValue: 'OpenAI'
        },
        {
          name: '模型型号',
          description: '选择具体的AI模型版本',
          required: true,
          type: 'select',
          defaultValue: 'gpt-4-turbo'
        },
        {
          name: 'Prompt 提示词',
          description: '输入给AI的提示词模板，支持变量插值',
          required: true,
          type: 'textarea',
          defaultValue: '请根据输入的图片生成动画效果描述...'
        },
        {
          name: '温度 (Temperature)',
          description: '控制生成结果的随机性，范围 0-2',
          required: false,
          type: 'number',
          defaultValue: '0.7'
        }
      ]
    },
    {
      id: 'step-2',
      number: 2,
      title: '数据预处理',
      description: '对输入数据进行清洗和格式转换',
      icon: '',
      parameters: [
        {
          name: '数据转换',
          description: '对输入数据进行类型转换或格式化',
          required: false,
          type: 'string',
          defaultValue: '自动识别'
        },
        {
          name: '数据清洗',
          description: '去除无效数据、空值处理等',
          required: false,
          type: 'boolean',
          defaultValue: 'true'
        },
        {
          name: '归一化',
          description: '是否对数值数据进行归一化处理',
          required: false,
          type: 'boolean',
          defaultValue: 'false'
        }
      ]
    },
    {
      id: 'step-3',
      number: 3,
      title: '执行处理',
      description: '调用AI模型或算法处理数据',
      icon: '',
      parameters: [
        {
          name: '处理函数',
          description: '选择执行的处理函数或AI模型',
          required: true,
          type: 'select',
          defaultValue: '默认处理器'
        },
        {
          name: '超时时间',
          description: '设置处理的最大超时时间（秒）',
          required: false,
          type: 'number',
          defaultValue: '30'
        },
        {
          name: '重试次数',
          description: '失败时的自动重试次数',
          required: false,
          type: 'number',
          defaultValue: '3'
        },
        {
          name: '并发模式',
          description: '是否启用并发处理以提升性能',
          required: false,
          type: 'boolean',
          defaultValue: 'false'
        }
      ]
    },
    {
      id: 'step-4',
      number: 4,
      title: '输出结果',
      description: '处理结果并传递给下游节点',
      icon: '',
      parameters: [
        {
          name: '输出端口',
          description: '定义节点的输出端口和数据结构',
          required: true,
          type: 'array',
          defaultValue: '[{ name: "output", type: "any" }]'
        },
        {
          name: '结果缓存',
          description: '是否缓存处理结果以避免重复计算',
          required: false,
          type: 'boolean',
          defaultValue: 'true'
        },
        {
          name: '错误处理',
          description: '选择错误处理策略（中断、跳过、使用默认值）',
          required: false,
          type: 'select',
          defaultValue: '中断执行'
        },
        {
          name: '日志记录',
          description: '是否记录节点执行日志和性能数据',
          required: false,
          type: 'boolean',
          defaultValue: 'true'
        }
      ]
    }
  ]
}

const reviews = [
  {
    id: 1,
    user: {
      name: '设计师小王',
      avatar: '',
      verified: true
    },
    rating: 5,
    content: '非常好用！帮我节省了大量时间，动画效果也很专业。特别喜欢360度旋转效果，完美应用到我的电商产品展示中。',
    likes: 45,
    date: '2天前',
    helpful: true
  },
  {
    id: 2,
    user: {
      name: '营销达人',
      avatar: '',
      verified: false
    },
    rating: 4,
    content: '效果不错，就是有时候处理大图会比较慢。建议增加批量处理功能。',
    likes: 23,
    date: '1周前',
    helpful: false
  },
  {
    id: 3,
    user: {
      name: '创业者李总',
      avatar: '',
      verified: true
    },
    rating: 5,
    content: '太棒了！作为非专业人士也能制作出专业级的动画效果，推荐给所有需要制作产品动画的朋友。',
    likes: 67,
    date: '2周前',
    helpful: true
  }
]

const qaList = [
  {
    id: 1,
    question: '支持批量处理吗？',
    answer: '目前支持批量上传，但需要逐个设置动画参数。批量处理功能正在开发中。',
    askedBy: '用户123',
    answeredBy: '张小明',
    isBestAnswer: true,
    votes: 28
  },
  {
    id: 2,
    question: '生成的GIF文件太大怎么办？',
    answer: '可以尝试降低帧率或缩小图片尺寸。建议使用15-24帧的帧率，在保证流畅的同时减小文件大小。',
    askedBy: '设计新手',
    answeredBy: '张小明',
    isBestAnswer: true,
    votes: 15
  }
]

export default function WorkflowIntroPage() {
  const { id } = useParams()
  const navigate = useNavigate()
  const [sortReviews, setSortReviews] = useState<'latest' | 'helpful'>('helpful')

  const handleApplyWorkflow = () => {
    alert(`已将「${workflowData.title}」添加到我的工作台！\n\n请前往「我的工作台」查看。`)
    navigate('/workspace')
  }

  const handleSaveWorkflow = () => {
    alert(`已收藏「${workflowData.title}」到我的工作流！`)
  }

  return (
    <div className="intro-page">
      {/* 面包屑导航 */}
      <nav className="breadcrumb-nav">
        <a href="/explore" className="breadcrumb-link">探索</a>
        <span className="breadcrumb-separator">/</span>
        <a href="/explore?category=图像处理" className="breadcrumb-link">图像处理</a>
        <span className="breadcrumb-separator">/</span>
        <span className="breadcrumb-current">{workflowData.title}</span>
      </nav>

      {/* 头部区域 */}
      <header className="intro-header">
        {/* 操作按钮 */}
        <div className="intro-actions">
          <button onClick={handleApplyWorkflow} className="icon-action-btn primary-action" title="添加到我的工作台">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <line x1="12" y1="5" x2="12" y2="19"></line>
              <line x1="5" y1="12" x2="19" y2="12"></line>
            </svg>
          </button>
          <button onClick={handleSaveWorkflow} className="icon-action-btn" title="收藏到我的工作流">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
            </svg>
          </button>
          <button className="icon-action-btn" title="分享">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="18" cy="5" r="3"></circle>
              <circle cx="6" cy="12" r="3"></circle>
              <circle cx="18" cy="19" r="3"></circle>
              <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"></line>
              <line x1="15.41" y1="6.51" x2="8.59" y2="10.49"></line>
            </svg>
          </button>
        </div>

        <div className="intro-header-main">
          <div className="intro-title-section">
            {/* 标题和作者信息同行 */}
            <div className="title-author-row">
              <h1 className="intro-title">{workflowData.title}</h1>
              <div className="author-info">
                <span className="author-name">{workflowData.author.name}</span>
                {workflowData.author.badges.map((badge, index) => (
                  <span key={index} className="badge badge-author">{badge}</span>
                ))}
              </div>
              {/* 评分和统计 */}
              <div className="intro-stats">
                <span className="stat-text">{workflowData.ratingCount} 条评价</span>
                <span className="stat-divider">|</span>
                <div className="rating-stars">
                  <span className="rating-number">{workflowData.rating}</span>
                  <span className="stars">{'★'.repeat(5)}</span>
                </div>
                <span className="stat-divider">|</span>
                <span className="stat-text">{workflowData.usageCount.toLocaleString()} 次使用</span>
              </div>
            </div>

            <p className="intro-description">{workflowData.description}</p>
          </div>
        </div>

        {/* 产品概述 */}
        <div className="product-overview-inline">
          <p className="overview-text">{workflowData.overview}</p>
          <div className="overview-tags">
            {workflowData.tags.map((tag, index) => (
              <span key={index} className="overview-tag">{tag}</span>
            ))}
          </div>
        </div>
      </header>

      {/* 主要内容区 */}
      <div className="intro-content">
        {/* 应用案例 */}
        <section className="content-section">
          <h2 className="section-title">应用案例</h2>
          <div className="use-cases-grid">
            {workflowData.useCases.map((useCase, index) => (
              <div key={index} className="use-case-card">
                <div className="use-case-image">{useCase.image}</div>
                <div className="use-case-content">
                  <h3 className="use-case-title">{useCase.title}</h3>
                  <p className="use-case-description">{useCase.description}</p>
                  <div className="use-case-tags">
                    {useCase.tags.map((tag, tagIndex) => (
                      <span key={tagIndex} className="tag tag-small">{tag}</span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* 工作流程与参数配置 */}
        <section className="content-section">
          <h2 className="section-title">工作流程与参数配置</h2>
          <p className="section-subtitle">点击流程节点查看该步骤的详细参数配置</p>
          <WorkflowFlowChart steps={workflowData.steps} />
        </section>

        {/* 用户评价 */}
        <section className="content-section">
          <div className="reviews-header">
            <h2 className="section-title">用户评价</h2>
            <div className="reviews-sort">
              <button
                className={`sort-button ${sortReviews === 'helpful' ? 'active' : ''}`}
                onClick={() => setSortReviews('helpful')}
              >
                最有帮助
              </button>
              <button
                className={`sort-button ${sortReviews === 'latest' ? 'active' : ''}`}
                onClick={() => setSortReviews('latest')}
              >
                最新
              </button>
            </div>
          </div>

          {/* 评论列表 */}
          <div className="reviews-list">
            {reviews.map((review) => (
              <div key={review.id} className="review-card">
                <div className="review-header">
                  <div className="review-user">
                    <div className="review-avatar">{review.user.avatar}</div>
                    <div>
                      <div className="review-user-name">
                        {review.user.name}
                        {review.user.verified && <span className="verified-badge">✓</span>}
                      </div>
                      <div className="review-stars">
                        {'★'.repeat(review.rating)}{'☆'.repeat(5 - review.rating)}
                      </div>
                    </div>
                  </div>
                  <span className="review-date">{review.date}</span>
                </div>
                <p className="review-content">{review.content}</p>
                <div className="review-actions">
                  <button className="review-action-button">
                    有帮助 ({review.likes})
                  </button>
                  <button className="review-action-button">回复</button>
                </div>
              </div>
            ))}
          </div>

          {/* 写评价按钮 */}
          <div className="write-review-section">
            <button className="btn btn-primary">写评价</button>
          </div>
        </section>

        {/* 问题解答 */}
        <section className="content-section">
          <div className="qa-header">
            <h2 className="section-title">问题解答</h2>
            <button className="btn btn-secondary">提问</button>
          </div>

          <div className="qa-list">
            {qaList.map((qa) => (
              <div key={qa.id} className="qa-card">
                <div className="qa-question">
                  <div className="qa-votes">
                    <button className="vote-button">▲</button>
                    <span className="vote-count">{qa.votes}</span>
                    <button className="vote-button">▼</button>
                  </div>
                  <div className="qa-content">
                    <h3 className="qa-question-text">Q: {qa.question}</h3>
                    <div className="qa-meta">
                      <span>提问者: {qa.askedBy}</span>
                    </div>
                  </div>
                </div>
                <div className="qa-answer">
                  {qa.isBestAnswer && <span className="best-answer-badge">✓ 最佳答案</span>}
                  <p className="qa-answer-text">A: {qa.answer}</p>
                  <div className="qa-meta">
                    <span>回答者: {qa.answeredBy}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>

      {/* 底部相关推荐 */}
      <section className="related-section">
        <h2 className="section-title">相关推荐</h2>
        <div className="related-grid">
          {[1, 2, 3, 4].map((item) => (
            <div key={item} className="related-card">
              <div className="related-icon"></div>
              <h3 className="related-title">图片批量处理工作流</h3>
              <div className="related-stats">
                <span>★ 4.6</span>
                <span>•</span>
                <span>2.1k 使用</span>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  )
}
