import { api } from './api'

// 工作流类型
export interface Workflow {
  id: string
  title: string
  description: string
  thumbnail?: string
  category: string
  tags: string[]
  version: string
  createdAt: string
  author?: {
    id: string
    name: string
    avatar?: string
  }
  _count?: {
    executions: number
    ratings: number
    favorites: number
  }
}

// 收藏工作流
export const favoriteWorkflow = async (workflowId: string): Promise<void> => {
  try {
    await api.post(`/workflows/${workflowId}/favorite`)
  } catch (error) {
    console.error('收藏工作流失败:', error)
    throw error
  }
}

// 取消收藏工作流
export const unfavoriteWorkflow = async (workflowId: string): Promise<void> => {
  try {
    await api.delete(`/workflows/${workflowId}/favorite`)
  } catch (error) {
    console.error('取消收藏工作流失败:', error)
    throw error
  }
}

// 获取用户收藏的工作流列表
export const getFavoriteWorkflows = async (): Promise<Workflow[]> => {
  try {
    const response = await api.get('/users/favorites')
    return response.data.workflows
  } catch (error) {
    console.error('获取收藏列表失败:', error)
    throw error
  }
}

// 获取用户创建的工作流
export const getUserWorkflows = async (): Promise<Workflow[]> => {
  try {
    const response = await api.get('/users/workflows')
    return response.data.workflows
  } catch (error) {
    console.error('获取用户工作流失败:', error)
    throw error
  }
}

// 获取公开工作流列表
export const getPublicWorkflows = async (params?: {
  page?: number
  limit?: number
  category?: string
  search?: string
}): Promise<{ workflows: Workflow[]; pagination: any }> => {
  try {
    const response = await api.get('/workflows', { params })
    return response.data
  } catch (error) {
    console.error('获取工作流列表失败:', error)
    throw error
  }
}

// 获取工作流详情
export const getWorkflowDetail = async (workflowId: string): Promise<Workflow> => {
  try {
    const response = await api.get(`/workflows/${workflowId}`)
    return response.data.workflow
  } catch (error) {
    console.error('获取工作流详情失败:', error)
    throw error
  }
}
