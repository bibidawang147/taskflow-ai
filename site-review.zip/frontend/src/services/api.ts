import axios from 'axios'

interface EnvAwareImportMeta extends ImportMeta {
  env: Record<string, string | undefined>
}

const API_BASE_URL =
  (typeof import.meta !== 'undefined'
    ? ((import.meta as EnvAwareImportMeta).env?.VITE_API_URL)
    : undefined) || 'http://localhost:5000/api'

export const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
})

// 请求拦截器 - 添加认证令牌
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

// 响应拦截器 - 处理认证错误
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // 清除无效的令牌
      localStorage.removeItem('token')
      // 重定向到登录页面
      window.location.href = '/login'
    }
    return Promise.reject(error)
  }
)

export default api
