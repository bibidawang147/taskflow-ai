import { Request, Response } from 'express';
import { aiProxyService } from '../services/ai-proxy.service';
import { getModelsForTier } from '../config/model-pricing';
import prisma from '../utils/database';

/**
 * 获取可用模型列表
 */
export const getAvailableModels = async (req: Request, res: Response) => {
  try {
    const userId = (req as any).user.id;

    // 获取用户等级
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: { tier: true },
    });

    if (!user) {
      return res.status(404).json({
        success: false,
        message: '用户不存在',
      });
    }

    const models = await aiProxyService.getAvailableModels(user.tier);

    // 按提供商分组
    const groupedModels = models.reduce((acc: any, model) => {
      if (!acc[model.provider]) {
        acc[model.provider] = [];
      }
      acc[model.provider].push({
        modelId: model.modelId,
        modelName: model.modelName,
        description: model.description,
        inputPrice: model.inputPrice,
        outputPrice: model.outputPrice,
        category: model.category,
        maxTokens: model.maxTokens,
        features: model.features,
      });
      return acc;
    }, {});

    res.json({
      success: true,
      data: {
        userTier: user.tier,
        models: groupedModels,
        totalCount: models.length,
      },
    });
  } catch (error: any) {
    console.error('获取模型列表失败:', error);
    res.status(500).json({
      success: false,
      message: error.message || '获取模型列表失败',
    });
  }
};

/**
 * 调用 AI 对话
 */
export const chat = async (req: Request, res: Response) => {
  try {
    const userId = (req as any).user.id;
    const {
      provider,
      model,
      messages,
      temperature,
      maxTokens,
      workflowId,
      executionId,
    } = req.body;

    // 验证必填字段
    if (!provider || !model || !messages || !Array.isArray(messages)) {
      return res.status(400).json({
        success: false,
        message: '缺少必填参数或参数格式错误',
      });
    }

    // 调用 AI 服务
    const response = await aiProxyService.chat({
      provider,
      model,
      messages,
      userId,
      temperature,
      maxTokens,
      workflowId,
      executionId,
    });

    res.json({
      success: true,
      data: {
        content: response.content,
        usage: {
          inputTokens: response.inputTokens,
          outputTokens: response.outputTokens,
          totalTokens: response.totalTokens,
        },
        cost: response.cost,
        finishReason: response.finishReason,
      },
    });
  } catch (error: any) {
    console.error('AI 对话失败:', error);

    // 处理特定错误
    if (error.message.includes('积分不足')) {
      return res.status(402).json({
        success: false,
        message: error.message,
        code: 'INSUFFICIENT_CREDIT',
      });
    }

    if (error.message.includes('会员等级')) {
      return res.status(403).json({
        success: false,
        message: error.message,
        code: 'TIER_REQUIRED',
      });
    }

    res.status(500).json({
      success: false,
      message: error.message || 'AI 对话失败',
    });
  }
};

/**
 * 测试 AI 连接（不计费）
 */
export const testConnection = async (req: Request, res: Response) => {
  try {
    const { provider } = req.body;

    // 简单的连接测试
    const testMessages = [
      { role: 'user', content: 'Hello' }
    ];

    let isConnected = false;
    let errorMessage = '';

    try {
      // 这里可以做一个简单的 API 健康检查
      // 实际项目中可能需要调用各个提供商的 health check 端点
      isConnected = true;
    } catch (error: any) {
      errorMessage = error.message;
    }

    res.json({
      success: true,
      data: {
        provider,
        isConnected,
        errorMessage,
      },
    });
  } catch (error: any) {
    console.error('测试连接失败:', error);
    res.status(500).json({
      success: false,
      message: error.message || '测试连接失败',
    });
  }
};
