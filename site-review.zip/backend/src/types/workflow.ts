export interface WorkflowNode {
  id: string
  type: 'input' | 'llm' | 'tool' | 'condition' | 'output'
  label: string
  position: {
    x: number
    y: number
  }
  config: Record<string, any>
}

export interface WorkflowEdge {
  id: string
  source: string
  target: string
  sourceHandle?: string
  targetHandle?: string
}

export interface WorkflowConfig {
  nodes: WorkflowNode[]
  edges: WorkflowEdge[]
}
