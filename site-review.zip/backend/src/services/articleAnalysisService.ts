import axios from 'axios'

/**
 * 文章分析服务
 * 从URL抓取文章内容，并使用AI分析提取工作流
 */
export class ArticleAnalysisService {
  /**
   * 从URL抓取文章内容
   */
  static async fetchArticleContent(url: string): Promise<{
    title: string
    content: string
    excerpt: string
  }> {
    try {
      // 使用 Jina Reader API 来获取干净的文章内容
      const jinaUrl = `https://r.jina.ai/${url}`

      const response = await axios.get(jinaUrl, {
        headers: {
          'Accept': 'application/json',
          'X-Return-Format': 'markdown'
        },
        timeout: 30000
      })

      // 如果返回的是JSON格式
      if (response.data && typeof response.data === 'object') {
        return {
          title: response.data.title || '未命名文章',
          content: response.data.content || response.data.text || '',
          excerpt: response.data.description || ''
        }
      }

      // 如果返回的是纯文本
      const text = typeof response.data === 'string' ? response.data : JSON.stringify(response.data)

      return {
        title: this.extractTitle(text),
        content: text,
        excerpt: text.slice(0, 200)
      }
    } catch (error: any) {
      console.error('抓取文章失败:', error.message)

      // 如果Jina API失败，尝试直接获取
      try {
        const response = await axios.get(url, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (compatible; WorkflowBot/1.0)'
          },
          timeout: 15000
        })

        const html = response.data
        const title = this.extractTitleFromHtml(html)
        const content = this.stripHtml(html)

        return {
          title,
          content,
          excerpt: content.slice(0, 200)
        }
      } catch (fallbackError) {
        throw new Error('无法抓取文章内容，请检查URL是否正确')
      }
    }
  }

  /**
   * 使用AI分析文章并提取工作流步骤
   */
  static async analyzeArticleAndExtractWorkflow(
    title: string,
    content: string,
    apiKey?: string
  ): Promise<{
    workflowTitle: string
    workflowDescription: string
    steps: WorkflowStep[]
    category: string
    tags: string[]
  }> {
    // 截取内容（避免超过token限制）
    const truncatedContent = content.slice(0, 8000)

    const prompt = `你是一个专业的工作流程分析专家。请仔细阅读以下文章，提取其中描述的工作流程、步骤或方法论。

文章标题：${title}

文章内容：
${truncatedContent}

请分析这篇文章并提取工作流程信息，返回JSON格式：

{
  "workflowTitle": "工作流标题",
  "workflowDescription": "工作流简短描述",
  "category": "工作流分类（如：内容创作、数据分析、产品设计等）",
  "tags": ["标签1", "标签2"],
  "steps": [
    {
      "stepNumber": 1,
      "title": "步骤标题",
      "description": "步骤详细描述",
      "type": "llm|tool|condition|transform",
      "config": {
        "prompt": "如果是AI步骤，这里是提示词",
        "tool": "如果是工具步骤，这里是工具名称",
        "condition": "如果是条件步骤，这里是判断条件"
      }
    }
  ]
}

注意：
1. 仔细分析文章内容，提取实际的工作流程步骤
2. 每个步骤要具体且可执行
3. type字段选择：
   - "llm": AI处理步骤（如写作、分析、总结）
   - "tool": 工具调用步骤（如搜索、API调用）
   - "condition": 条件判断步骤
   - "transform": 数据转换步骤
4. 如果文章没有明确的流程，尝试从内容中归纳出合理的步骤
5. 至少提取3-8个步骤

只返回JSON，不要其他内容。`

    try {
      // 调用OpenAI API
      const openaiApiKey = apiKey || process.env.OPENAI_API_KEY

      if (!openaiApiKey) {
        throw new Error('未配置OpenAI API Key')
      }

      const response = await axios.post(
        'https://api.openai.com/v1/chat/completions',
        {
          model: 'gpt-4o',
          messages: [
            {
              role: 'system',
              content: '你是一个专业的工作流程分析专家，擅长从文章中提取和抽象工作流程。'
            },
            {
              role: 'user',
              content: prompt
            }
          ],
          temperature: 0.3,
          response_format: { type: 'json_object' }
        },
        {
          headers: {
            'Authorization': `Bearer ${openaiApiKey}`,
            'Content-Type': 'application/json'
          },
          timeout: 60000
        }
      )

      const result = JSON.parse(response.data.choices[0].message.content)

      return {
        workflowTitle: result.workflowTitle || title,
        workflowDescription: result.workflowDescription || '从文章中提取的工作流',
        steps: result.steps || [],
        category: result.category || 'general',
        tags: result.tags || []
      }
    } catch (error: any) {
      console.error('AI分析失败:', error.message)
      throw new Error('文章分析失败: ' + error.message)
    }
  }

  /**
   * 从文本中提取标题
   */
  private static extractTitle(text: string): string {
    const lines = text.split('\n').filter(line => line.trim())
    return lines[0]?.trim() || '未命名文章'
  }

  /**
   * 从HTML中提取标题
   */
  private static extractTitleFromHtml(html: string): string {
    const titleMatch = html.match(/<title[^>]*>([^<]+)<\/title>/i)
    return titleMatch?.[1]?.trim() || '未命名文章'
  }

  /**
   * 移除HTML标签
   */
  private static stripHtml(html: string): string {
    return html
      .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '')
      .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')
      .replace(/<[^>]+>/g, ' ')
      .replace(/\s+/g, ' ')
      .trim()
  }
}

export interface WorkflowStep {
  stepNumber: number
  title: string
  description: string
  type: 'llm' | 'tool' | 'condition' | 'transform'
  config: {
    prompt?: string
    tool?: string
    condition?: string
    [key: string]: any
  }
}
