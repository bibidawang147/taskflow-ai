import OpenAI from 'openai';
import Anthropic from '@anthropic-ai/sdk';
import axios from 'axios';
import prisma from '../utils/database';
import { CreditService } from './credit.service';

// AI 请求接口
export interface AIRequest {
  provider: 'openai' | 'anthropic' | 'doubao' | 'qwen' | 'zhipu';
  model: string;
  messages: Array<{ role: string; content: string }>;
  userId: string;
  workflowId?: string;
  executionId?: string;
  temperature?: number;
  maxTokens?: number;
  stream?: boolean;
}

// AI 响应接口
export interface AIResponse {
  content: string;
  inputTokens: number;
  outputTokens: number;
  totalTokens: number;
  cost: number;
  finishReason?: string;
}

export class AIProxyService {
  private openai: OpenAI;
  private anthropic: Anthropic;
  private creditService: CreditService;

  constructor() {
    // 初始化各个 AI 服务客户端
    this.openai = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY,
    });

    this.anthropic = new Anthropic({
      apiKey: process.env.ANTHROPIC_API_KEY,
    });

    this.creditService = new CreditService();
  }

  /**
   * 统一的 AI 调用接口
   */
  async chat(request: AIRequest): Promise<AIResponse> {
    try {
      // 1. 检查用户积分
      const hasCredit = await this.creditService.checkCredit(request.userId);
      if (!hasCredit) {
        throw new Error('积分不足，请充值');
      }

      // 2. 获取模型定价
      const pricing = await this.getModelPricing(request.provider, request.model);
      if (!pricing) {
        throw new Error(`模型 ${request.provider}:${request.model} 未找到定价信息`);
      }

      // 3. 检查用户等级是否允许使用该模型
      const user = await prisma.user.findUnique({
        where: { id: request.userId },
      });

      if (!user) {
        throw new Error('用户不存在');
      }

      const allowedTiers = pricing.allowedTiers.split(',');
      if (!allowedTiers.includes(user.tier)) {
        throw new Error(`您的会员等级 (${user.tier}) 无法使用此模型，请升级会员`);
      }

      // 4. 路由到对应的提供商
      let response: AIResponse;

      switch (request.provider) {
        case 'openai':
          response = await this.callOpenAI(request, pricing);
          break;
        case 'anthropic':
          response = await this.callAnthropic(request, pricing);
          break;
        case 'doubao':
          response = await this.callDoubao(request, pricing);
          break;
        case 'qwen':
          response = await this.callQwen(request, pricing);
          break;
        case 'zhipu':
          response = await this.callZhipu(request, pricing);
          break;
        default:
          throw new Error(`不支持的 AI 提供商: ${request.provider}`);
      }

      // 5. 扣除积分并记录日志
      await this.creditService.deductCredit({
        userId: request.userId,
        cost: response.cost,
        provider: request.provider,
        model: request.model,
        inputTokens: response.inputTokens,
        outputTokens: response.outputTokens,
        totalTokens: response.totalTokens,
        workflowId: request.workflowId,
        executionId: request.executionId,
        status: 'success',
      });

      return response;
    } catch (error: any) {
      // 记录失败日志（不扣费）
      await this.creditService.logUsage({
        userId: request.userId,
        provider: request.provider,
        model: request.model,
        inputTokens: 0,
        outputTokens: 0,
        totalTokens: 0,
        cost: 0,
        workflowId: request.workflowId,
        executionId: request.executionId,
        status: 'failed',
        errorMessage: error.message,
      });

      throw error;
    }
  }

  /**
   * 调用 OpenAI API
   */
  private async callOpenAI(request: AIRequest, pricing: any): Promise<AIResponse> {
    const completion = await this.openai.chat.completions.create({
      model: request.model,
      messages: request.messages as any,
      temperature: request.temperature ?? 0.7,
      max_tokens: request.maxTokens,
    });

    const inputTokens = completion.usage?.prompt_tokens ?? 0;
    const outputTokens = completion.usage?.completion_tokens ?? 0;
    const totalTokens = completion.usage?.total_tokens ?? 0;

    // 计算费用
    const cost = this.calculateCost(inputTokens, outputTokens, pricing);

    return {
      content: completion.choices[0]?.message?.content ?? '',
      inputTokens,
      outputTokens,
      totalTokens,
      cost,
      finishReason: completion.choices[0]?.finish_reason ?? undefined,
    };
  }

  /**
   * 调用 Anthropic Claude API
   */
  private async callAnthropic(request: AIRequest, pricing: any): Promise<AIResponse> {
    const message = await this.anthropic.messages.create({
      model: request.model,
      max_tokens: request.maxTokens ?? 4096,
      temperature: request.temperature ?? 0.7,
      messages: request.messages.map(msg => ({
        role: msg.role as 'user' | 'assistant',
        content: msg.content,
      })),
    });

    const inputTokens = message.usage.input_tokens;
    const outputTokens = message.usage.output_tokens;
    const totalTokens = inputTokens + outputTokens;

    const cost = this.calculateCost(inputTokens, outputTokens, pricing);

    const content = message.content
      .filter((block) => block.type === 'text')
      .map((block: any) => block.text)
      .join('');

    return {
      content,
      inputTokens,
      outputTokens,
      totalTokens,
      cost,
      finishReason: message.stop_reason ?? undefined,
    };
  }

  /**
   * 调用豆包 API（字节跳动）
   */
  private async callDoubao(request: AIRequest, pricing: any): Promise<AIResponse> {
    // 豆包 API 调用示例（需要根据实际 API 文档调整）
    const response = await axios.post(
      'https://ark.cn-beijing.volces.com/api/v3/chat/completions',
      {
        model: request.model,
        messages: request.messages,
        temperature: request.temperature ?? 0.7,
        max_tokens: request.maxTokens,
      },
      {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${process.env.DOUBAO_API_KEY}`,
        },
      }
    );

    const data = response.data;
    const inputTokens = data.usage?.prompt_tokens ?? 0;
    const outputTokens = data.usage?.completion_tokens ?? 0;
    const totalTokens = data.usage?.total_tokens ?? 0;

    const cost = this.calculateCost(inputTokens, outputTokens, pricing);

    return {
      content: data.choices[0]?.message?.content ?? '',
      inputTokens,
      outputTokens,
      totalTokens,
      cost,
      finishReason: data.choices[0]?.finish_reason,
    };
  }

  /**
   * 调用通义千问 API
   */
  private async callQwen(request: AIRequest, pricing: any): Promise<AIResponse> {
    // 通义千问 API 调用示例（需要根据实际 API 文档调整）
    const response = await axios.post(
      'https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation',
      {
        model: request.model,
        input: {
          messages: request.messages,
        },
        parameters: {
          temperature: request.temperature ?? 0.7,
          max_tokens: request.maxTokens,
        },
      },
      {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${process.env.QWEN_API_KEY}`,
        },
      }
    );

    const data = response.data;
    const inputTokens = data.usage?.input_tokens ?? 0;
    const outputTokens = data.usage?.output_tokens ?? 0;
    const totalTokens = inputTokens + outputTokens;

    const cost = this.calculateCost(inputTokens, outputTokens, pricing);

    return {
      content: data.output?.text ?? '',
      inputTokens,
      outputTokens,
      totalTokens,
      cost,
    };
  }

  /**
   * 调用智谱 AI API
   */
  private async callZhipu(request: AIRequest, pricing: any): Promise<AIResponse> {
    // 智谱 API 调用示例（需要根据实际 API 文档调整）
    const response = await axios.post(
      'https://open.bigmodel.cn/api/paas/v4/chat/completions',
      {
        model: request.model,
        messages: request.messages,
        temperature: request.temperature ?? 0.7,
        max_tokens: request.maxTokens,
      },
      {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${process.env.ZHIPU_API_KEY}`,
        },
      }
    );

    const data = response.data;
    const inputTokens = data.usage?.prompt_tokens ?? 0;
    const outputTokens = data.usage?.completion_tokens ?? 0;
    const totalTokens = data.usage?.total_tokens ?? 0;

    const cost = this.calculateCost(inputTokens, outputTokens, pricing);

    return {
      content: data.choices[0]?.message?.content ?? '',
      inputTokens,
      outputTokens,
      totalTokens,
      cost,
      finishReason: data.choices[0]?.finish_reason,
    };
  }

  /**
   * 计算费用
   */
  private calculateCost(inputTokens: number, outputTokens: number, pricing: any): number {
    // pricing.inputPrice 和 outputPrice 是每 1K tokens 的价格
    const inputCost = Math.ceil((inputTokens / 1000) * pricing.inputPrice);
    const outputCost = Math.ceil((outputTokens / 1000) * pricing.outputPrice);
    return inputCost + outputCost;
  }

  /**
   * 获取模型定价
   */
  private async getModelPricing(provider: string, modelId: string) {
    return await prisma.modelPricing.findUnique({
      where: {
        provider_modelId: {
          provider,
          modelId,
        },
      },
    });
  }

  /**
   * 获取所有可用模型列表
   */
  async getAvailableModels(userTier: string = 'free') {
    const models = await prisma.modelPricing.findMany({
      where: {
        isActive: true,
      },
      orderBy: {
        sortOrder: 'asc',
      },
    });

    // 过滤用户等级可用的模型
    return models.filter(model => {
      const allowedTiers = model.allowedTiers.split(',');
      return allowedTiers.includes(userTier);
    });
  }
}

export const aiProxyService = new AIProxyService();
