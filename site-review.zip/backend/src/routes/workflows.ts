import { Router } from 'express'
import { AuthenticatedRequest, authenticateToken } from '../middleware/auth'
import { Response } from 'express'
import prisma from '../utils/database'
import { WorkflowTemplateService } from '../services/workflowTemplateService'
import { ArticleAnalysisService } from '../services/articleAnalysisService'
import { MockArticleAnalysisService } from '../services/mockArticleAnalysisService'

const router = Router()

// 获取公开的工作流列表（不需要认证）
router.get('/', async (req, res: Response) => {
  try {
    const page = parseInt(req.query.page as string) || 1
    const limit = parseInt(req.query.limit as string) || 20
    const category = req.query.category as string
    const search = req.query.search as string

    const where: any = { isPublic: true }

    if (category) {
      where.category = category
    }

    if (search) {
      where.OR = [
        { title: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } }
      ]
    }

    const workflows = await prisma.workflow.findMany({
      where,
      select: {
        id: true,
        title: true,
        description: true,
        thumbnail: true,
        category: true,
        tags: true,
        version: true,
        createdAt: true,
        author: {
          select: {
            id: true,
            name: true,
            avatar: true
          }
        },
        _count: {
          select: {
            executions: true,
            ratings: true,
            favorites: true
          }
        }
      },
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * limit,
      take: limit
    })

    const total = await prisma.workflow.count({ where })

    res.status(200).json({
      workflows,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    })
  } catch (error) {
    console.error('获取工作流列表错误:', error)
    res.status(500).json({
      error: '获取工作流列表失败'
    })
  }
})

// 获取工作流详情（不需要认证）
router.get('/:id', async (req, res: Response) => {
  try {
    const { id } = req.params

    const workflow = await prisma.workflow.findUnique({
      where: { id },
      include: {
        author: {
          select: {
            id: true,
            name: true,
            avatar: true
          }
        },
        nodes: true,
        ratings: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                avatar: true
              }
            }
          }
        },
        comments: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                avatar: true
              }
            }
          },
          orderBy: { createdAt: 'desc' }
        },
        _count: {
          select: {
            executions: true,
            favorites: true
          }
        }
      }
    })

    if (!workflow) {
      return res.status(404).json({
        error: '工作流不存在'
      })
    }

    // 检查是否为私有工作流
    if (!workflow.isPublic) {
      return res.status(403).json({
        error: '无权访问此工作流'
      })
    }

    res.status(200).json({
      workflow
    })
  } catch (error) {
    console.error('获取工作流详情错误:', error)
    res.status(500).json({
      error: '获取工作流详情失败'
    })
  }
})

// 创建工作流（需要认证）
router.post('/', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const userId = req.user!.id
    const { title, description, category, tags, config, isPublic = false } = req.body

    const workflow = await prisma.workflow.create({
      data: {
        title,
        description,
        category,
        tags: tags || [],
        config,
        isPublic,
        authorId: userId
      },
      include: {
        author: {
          select: {
            id: true,
            name: true,
            avatar: true
          }
        }
      }
    })

    res.status(201).json({
      message: '工作流创建成功',
      workflow
    })
  } catch (error) {
    console.error('创建工作流错误:', error)
    res.status(500).json({
      error: '创建工作流失败'
    })
  }
})

// 收藏工作流（需要认证）
router.post('/:id/favorite', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const userId = req.user!.id
    const { id: workflowId } = req.params

    // 检查工作流是否存在
    const workflow = await prisma.workflow.findUnique({
      where: { id: workflowId }
    })

    if (!workflow) {
      return res.status(404).json({
        error: '工作流不存在'
      })
    }

    // 检查是否已经收藏
    const existingFavorite = await prisma.favorite.findUnique({
      where: {
        userId_workflowId: {
          userId,
          workflowId
        }
      }
    })

    if (existingFavorite) {
      return res.status(400).json({
        error: '已经收藏过此工作流'
      })
    }

    // 创建收藏
    await prisma.favorite.create({
      data: {
        userId,
        workflowId
      }
    })

    res.status(201).json({
      message: '收藏成功'
    })
  } catch (error) {
    console.error('收藏工作流错误:', error)
    res.status(500).json({
      error: '收藏工作流失败'
    })
  }
})

// 取消收藏工作流（需要认证）
router.delete('/:id/favorite', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const userId = req.user!.id
    const { id: workflowId } = req.params

    // 检查收藏是否存在
    const favorite = await prisma.favorite.findUnique({
      where: {
        userId_workflowId: {
          userId,
          workflowId
        }
      }
    })

    if (!favorite) {
      return res.status(404).json({
        error: '未收藏此工作流'
      })
    }

    // 删除收藏
    await prisma.favorite.delete({
      where: {
        id: favorite.id
      }
    })

    res.status(200).json({
      message: '取消收藏成功'
    })
  } catch (error) {
    console.error('取消收藏工作流错误:', error)
    res.status(500).json({
      error: '取消收藏工作流失败'
    })
  }
})

// 从文章URL生成智能工作流（需要认证）
router.post('/generate/from-article', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const userId = req.user!.id
    const { url, autoSave = true } = req.body

    // 验证URL
    if (!url) {
      return res.status(400).json({
        error: 'URL不能为空'
      })
    }

    // URL格式验证
    try {
      new URL(url)
    } catch {
      return res.status(400).json({
        error: '无效的URL格式'
      })
    }

    console.log('开始处理文章:', url)

    // 步骤1: 抓取文章内容
    let articleData
    try {
      articleData = await ArticleAnalysisService.fetchArticleContent(url)
      console.log('文章抓取成功:', articleData.title)
    } catch (error: any) {
      console.error('抓取文章失败:', error)
      return res.status(400).json({
        error: '无法抓取文章内容: ' + error.message
      })
    }

    // 步骤2: 使用AI分析文章并提取工作流
    let analysisResult
    try {
      analysisResult = await ArticleAnalysisService.analyzeArticleAndExtractWorkflow(
        articleData.title,
        articleData.content,
        process.env.OPENAI_API_KEY
      )
      console.log('AI分析成功，提取了', analysisResult.steps.length, '个步骤')
    } catch (error: any) {
      console.error('AI分析失败:', error)
      return res.status(500).json({
        error: '文章分析失败: ' + error.message
      })
    }

    // 步骤3: 根据分析结果生成工作流配置
    const workflowConfig = WorkflowTemplateService.generateDynamicWorkflow(
      analysisResult.steps,
      url
    )

    console.log('工作流生成成功，包含', workflowConfig.nodes.length, '个节点')

    // 如果需要自动保存，则创建工作流
    if (autoSave) {
      const workflow = await prisma.workflow.create({
        data: {
          title: analysisResult.workflowTitle,
          description: analysisResult.workflowDescription,
          category: analysisResult.category,
          tags: analysisResult.tags.join(','),
          config: JSON.parse(JSON.stringify(workflowConfig)),
          isPublic: false, // 默认私有
          authorId: userId,
          version: '1.0.0'
        },
        include: {
          author: {
            select: {
              id: true,
              name: true,
              avatar: true
            }
          }
        }
      })

      return res.status(201).json({
        message: '工作流创建成功',
        workflow,
        analysis: {
          articleTitle: articleData.title,
          stepsExtracted: analysisResult.steps.length,
          category: analysisResult.category,
          tags: analysisResult.tags
        }
      })
    }

    // 如果不自动保存，只返回配置
    res.status(200).json({
      message: '工作流配置生成成功',
      config: workflowConfig,
      metadata: {
        title: analysisResult.workflowTitle,
        description: analysisResult.workflowDescription,
        category: analysisResult.category,
        tags: analysisResult.tags
      },
      analysis: {
        articleTitle: articleData.title,
        stepsExtracted: analysisResult.steps.length
      }
    })
  } catch (error: any) {
    console.error('生成工作流错误:', error)
    res.status(500).json({
      error: '生成工作流失败: ' + (error.message || '未知错误')
    })
  }
})

// 🧪 从文章URL生成智能工作流 - 模拟模式（用于测试，无需OpenAI API Key）
router.post('/generate/from-article-mock', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const userId = req.user!.id
    const { url, autoSave = true } = req.body

    // 验证URL
    if (!url) {
      return res.status(400).json({
        error: 'URL不能为空'
      })
    }

    // URL格式验证
    try {
      new URL(url)
    } catch {
      return res.status(400).json({
        error: '无效的URL格式'
      })
    }

    console.log('🧪 [测试模式] 开始处理文章:', url)

    // 步骤1: 模拟抓取文章内容
    let articleData
    try {
      articleData = await MockArticleAnalysisService.fetchArticleContent(url)
      console.log('🧪 [测试模式] 文章抓取成功:', articleData.title)
    } catch (error: any) {
      console.error('🧪 [测试模式] 抓取文章失败:', error)
      return res.status(400).json({
        error: '无法抓取文章内容: ' + error.message
      })
    }

    // 步骤2: 模拟AI分析文章并提取工作流
    let analysisResult
    try {
      analysisResult = await MockArticleAnalysisService.analyzeArticleAndExtractWorkflow(
        articleData.title,
        articleData.content
      )
      console.log('🧪 [测试模式] AI分析成功，提取了', analysisResult.steps.length, '个步骤')
    } catch (error: any) {
      console.error('🧪 [测试模式] AI分析失败:', error)
      return res.status(500).json({
        error: '文章分析失败: ' + error.message
      })
    }

    // 步骤3: 根据分析结果生成工作流配置
    const workflowConfig = WorkflowTemplateService.generateDynamicWorkflow(
      analysisResult.steps,
      url
    )

    console.log('🧪 [测试模式] 工作流生成成功，包含', workflowConfig.nodes.length, '个节点')

    // 如果需要自动保存，则创建工作流
    if (autoSave) {
      const workflow = await prisma.workflow.create({
        data: {
          title: `[测试] ${analysisResult.workflowTitle}`,
          description: `${analysisResult.workflowDescription} (模拟模式生成)`,
          category: analysisResult.category,
          tags: analysisResult.tags.join(','),
          config: JSON.parse(JSON.stringify(workflowConfig)),
          isPublic: false, // 默认私有
          authorId: userId,
          version: '1.0.0'
        },
        include: {
          author: {
            select: {
              id: true,
              name: true,
              avatar: true
            }
          }
        }
      })

      return res.status(201).json({
        message: '工作流创建成功（测试模式）',
        workflow,
        analysis: {
          articleTitle: articleData.title,
          stepsExtracted: analysisResult.steps.length,
          category: analysisResult.category,
          tags: analysisResult.tags
        },
        testMode: true
      })
    }

    // 如果不自动保存，只返回配置
    res.status(200).json({
      message: '工作流配置生成成功（测试模式）',
      config: workflowConfig,
      metadata: {
        title: analysisResult.workflowTitle,
        description: analysisResult.workflowDescription,
        category: analysisResult.category,
        tags: analysisResult.tags
      },
      analysis: {
        articleTitle: articleData.title,
        stepsExtracted: analysisResult.steps.length
      },
      testMode: true
    })
  } catch (error: any) {
    console.error('🧪 [测试模式] 生成工作流错误:', error)
    res.status(500).json({
      error: '生成工作流失败: ' + (error.message || '未知错误')
    })
  }
})

// 获取可用的工作流模板列表
router.get('/templates', async (req, res: Response) => {
  try {
    const templates = [
      {
        id: 'knowledge-extraction',
        name: '文章知识提取',
        description: '从文章URL提取实体、关系，生成知识图谱',
        category: 'knowledge-extraction',
        icon: '🧠',
        tags: ['知识提取', '文章分析', 'AI'],
        preview: '/templates/knowledge-extraction.png',
        requiredInputs: [
          {
            name: 'url',
            label: '文章URL',
            type: 'text',
            placeholder: 'https://example.com/article'
          }
        ]
      }
      // 未来可以添加更多模板
    ]

    res.status(200).json({
      templates
    })
  } catch (error) {
    console.error('获取模板列表错误:', error)
    res.status(500).json({
      error: '获取模板列表失败'
    })
  }
})

export default router