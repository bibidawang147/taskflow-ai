import { Request, Response, NextFunction } from 'express'

export interface AppError extends Error {
  statusCode?: number
  status?: string
  isOperational?: boolean
}

export const errorHandler = (
  err: AppError,
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const statusCode = err.statusCode || 500
  const status = err.status || 'error'

  // 开发环境显示详细错误信息
  if (process.env.NODE_ENV === 'development') {
    console.error('Error:', err)
    return res.status(statusCode).json({
      status,
      error: err.message,
      stack: err.stack
    })
  }

  // 生产环境只显示安全的错误信息
  if (err.isOperational) {
    return res.status(statusCode).json({
      status,
      error: err.message
    })
  }

  // 未知错误，不暴露给客户端
  console.error('Unexpected error:', err)
  res.status(500).json({
    status: 'error',
    error: '服务器内部错误'
  })
}

export const createError = (message: string, statusCode: number = 500): AppError => {
  const error: AppError = new Error(message)
  error.statusCode = statusCode
  error.isOperational = true
  return error
}