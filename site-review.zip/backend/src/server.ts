import express from 'express'
import cors from 'cors'
import helmet from 'helmet'
import morgan from 'morgan'
import dotenv from 'dotenv'
import rateLimit from 'express-rate-limit'

import authRoutes from './routes/auth'
import workflowRoutes from './routes/workflows'
import userRoutes from './routes/users'
import workItemRoutes from './routes/workItems'
import aiRoutes from './routes/ai'
import creditRoutes from './routes/credit'
import workspaceRoutes from './routes/workspace'
import { errorHandler } from './middleware/errorHandler'
import { authenticateToken } from './middleware/auth'

dotenv.config()

const app = express()
const PORT = process.env.PORT || 3000

// 安全中间件
app.use(helmet())
app.use(cors({
  origin: process.env.NODE_ENV === 'production'
    ? ['https://your-domain.com']
    : ['http://localhost:3000', 'http://localhost:3001', 'http://localhost:5173', 'http://127.0.0.1:5173'],
  credentials: true
}))

// 限流
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15分钟
  max: 100, // 每个IP最多100次请求
  message: '请求过于频繁，请稍后再试'
})
app.use(limiter)

// 日志
app.use(morgan('combined'))

// 解析JSON
app.use(express.json({ limit: '10mb' }))
app.use(express.urlencoded({ extended: true }))

// 健康检查
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'OK', timestamp: new Date().toISOString() })
})

// 路由
app.use('/api/auth', authRoutes)
app.use('/api/users', authenticateToken, userRoutes)
app.use('/api/workflows', workflowRoutes)
app.use('/api/work-items', workItemRoutes)
app.use('/api/workspace', workspaceRoutes)
app.use('/api/ai', aiRoutes)
app.use('/api/credit', creditRoutes)

// 错误处理
app.use(errorHandler)

// 404处理
app.use((req, res) => {
  res.status(404).json({ error: '接口不存在' })
})

app.listen(PORT, () => {
  console.log(`🚀 服务器运行在端口 ${PORT}`)
  console.log(`📊 健康检查: http://localhost:${PORT}/health`)
})